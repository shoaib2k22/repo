<?php

$server = $_REQUEST['server'];

$connection = ssh2_connect('vgg218yr', 22);
ssh2_auth_password($connection, 'alive007', 'Acc@0323');


if(!$connection){
	echo "Not connected";
}


$stream = ssh2_exec($connection, 'ksh /tmp/scripts/icms1.ksh '.$server);

stream_set_blocking($stream, true);
   $output = ssh2_fetch_stream($stream, SSH2_STREAM_STDIO);
   $message = str_replace(' ','',(stream_get_contents($output)));



   
switch ($server) {
  case "test":
    $message = "ValidServer";
    break;
  case "uppsala2":
    $message = "ValidServer";
    break;
  case "vgg218yr":
    $message = "ValidServer";
    break;
  case "vg4044yr":
    $message = "ValidServer";
    break;
  case "vg4044yr":
    $message = "ValidServer";
    break;
  case "votstehr":
    $message = "ValidServer";
    break;
  case "vgssh3hr":
    $message = "ValidServer";
    break;
  case "vg6672yw":
    $message = "ValidServer";
    break;
  case "vg6676yw":
    $message = "ValidServer";
    break;
  case "vg6675yw":
    $message = "ValidServer";
    break;
  case "vg6670yw":
    $message = "ValidServer";
    break;
  case "vg6673yw":
    $message = "ValidServer";
    break;
 case "vg6370hr":
    $message = "ValidServer";
    break;
  default:
    $message = "";
}

//$message = "ValidServer";   
   
if(trim($message) == "ValidServer"){
	$myObj = new stdClass();
	$myObj->code = 200;
	$myObj->msg = "Validation Successful";
	$myJSON = json_encode($myObj);
	echo $myJSON;
	die();
}
else{
	$myObj = new stdClass();
	$myObj->code = 400;
	$myObj->msg = "Validation Failed";
	$myJSON = json_encode($myObj);
	echo $myJSON;
	die();
}

    
  

?>