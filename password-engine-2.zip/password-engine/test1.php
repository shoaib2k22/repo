<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<title>Vodafone Password Engine</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet"/>
	
</head>

<body>
    <h4>Hello</h4>


<script>

onload = fetch("https://vodafone.sharepoint.com/sites/Vishal_Test/Shared%20Documents/AccessList.csv", { mode: 'no-cors'}).then(res => {
    return res.text()
}).then(data => {
    console.log(data);
})

/*
fetch('https://vodafone.sharepoint.com/sites/Vishal_Test/Shared%20Documents/AccessList.csv', { mode: 'no-cors'})
  .then(data => {
    console.log(data);
    return data;
  });
*/

/*
var settings = {
'cache': false,
'dataType': "text/csv",
"async": true,
"crossDomain": true,
"url": "https://vodafone.sharepoint.com/:x:/r/sites/Vishal_Test/Shared%20Documents/AccessList.csv?d=we1d79c76e1b046caaf3dcae7bb24261f&csf=1&web=1&e=Us3bwa",
"method": "GET",
"headers": {
"accept": "text/csv",
"Access-Control-Allow-Origin":"*"
}
}
$.ajax(settings).done(function (response) {
console.log(response);
});
*/
/*
$.ajax({
		 url:'https://vodafone.sharepoint.com/:x:/r/sites/Vishal_Test/Shared%20Documents/AccessList.csv?d=we1d79c76e1b046caaf3dcae7bb24261f&csf=1&web=1&e=Us3bwa',
		 success:function(result){
			console.log(result);
		 }
	 });


/*
window.onbeforeunload = confirmExit;

function confirmExit(){
  return "hello";
}
*/

/*
chrome.tabs.executeScript(1, { "code": "document.documentElement.outerHTML;" }, function (result) {
        console.log(result);
    });
*/
/*
$.get("https://landingpage.oitcloud.vodafone.com/", function(data){
    console.log(data); 
});
*/

/*
fetch('https://landingpage.oitcloud.vodafone.com/')
    .then(res => alert('Success'))
    .catch(err => alert('Failed'));
*/	
	
	
 //window.open("https://landingpage.oitcloud.vodafone.com/", "Google", "width=200,height=200");
 //window.close();
 
 
/* 
var printContent = document.getElementById(content2);

var windowUrl = 'https://landingpage.oitcloud.vodafone.com/';

var uniqueName = new Date();

var windowName = 'Print' + uniqueName.getTime();

var printWindow = window.open(windowUrl, windowName,'left=500,top=500,width=500,height=500');

//console.log(printWindow);
console.log(window.history);

$("#content2").html(printWindow);
*/



/*
let winRef = window.open("https://landingpage.oitcloud.vodafone.com/#", "winPopup");

console.log(winRef);
*/

/*
  $.ajax("https://landingpage.oitcloud.vodafone.com/#", {
    success: function(response) {
      $("#content2").html(response);
    }
  }); 
*/


/*
var userId = _spPageContextInfo.userId;
console.log(userId);
*/
//console.log(window);

/*     
$.get("https://ipinfo.io", function(response) {
		console.log(response);
	}, "json");

*/


/*
let ua = navigator;

console.log(ua);
*/


/*var userId = _spPageContextInfo.userId;

console.log(userId);*/


</script>

</body>


</html>