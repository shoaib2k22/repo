<?php
include('dbConnection.php');

$serverId = $_REQUEST['serverName'];
$userName = $_REQUEST['userName'];
$userPassword = $_REQUEST['userValue'];

$sql = "SELECT * FROM servers WHERE id = $serverId";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();
  $serverName = $row['host_name'];


set_time_limit(0);

$connection = ssh2_connect('vgg218yr', 22);
ssh2_auth_password($connection, 'alive007', 'Acc@0323');


$stream = ssh2_exec($connection, 'curl -k -u "VF-ROOT\LIVE008IA":"Bot08@0323" -X POST -H "Content-Type:application/json" -d "{\"flowUuid\":\"67323e47-fd23-42a1-9b1b-79b6ad62a3ba\",\"runName\":\"run1\",\"inputs\":{\"keyaction\":\"validation\",\"keyserver\":\"'.$serverName.'\",\"keyname\":\"'.$userName.'\",\"keyvalue\":\"'.$userPassword.'\"}}" "https://oo.vodafone.com/oo/rest/v2/executions"');

stream_set_blocking($stream, true);
$output = ssh2_fetch_stream($stream, SSH2_STREAM_STDIO);
$message = stream_get_contents($output);


$stream = ssh2_exec($connection, 'curl -k -u "VF-ROOT\LIVE008IA":"Bot08@0323" -X POST -H "Content-Type:application/json" -d "{\"flowUuid\":\"67323e47-fd23-42a1-9b1b-79b6ad62a3ba\",\"runName\":\"run1\",\"inputs\":{\"keyaction\":\"validation\",\"keyserver\":\"vgg218yr\",\"keyname\":\"accusr\",\"keyvalue\":\"Acc@0323\"}}" "https://oo.vodafone.com/oo/rest/v2/executions"');


sleep(40);


$validate = ssh2_exec($connection, 'curl -k -u "VF-ROOT\LIVE008IA":"Bot08@0323" -X GET -H "Content-Type:application/json" "https://oo.vodafone.com/oo/rest/v2/executions/'.$message.'/execution-log"');

stream_set_blocking($validate, true);
$output2 = ssh2_fetch_stream($validate, SSH2_STREAM_STDIO);
$message2 = stream_get_contents($output2);


$data = json_decode($message2, true);


if(isset($data['flowOutput']['Validation']) == 'login successful'){
	$myObj = new stdClass();
	$myObj->code = 200;
	$myObj->msg = "Validation Successful";
	$myJSON = json_encode($myObj);
	echo $myJSON;
	die();
}
else{
	$myObj = new stdClass();
	$myObj->code = 400;
	$myObj->msg = "Validation False: Please check your Service/Funnctional User Name & User Password";
	$myJSON = json_encode($myObj);
	echo $myJSON;
	die();
}

    
  

?>