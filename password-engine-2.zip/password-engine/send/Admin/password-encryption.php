<?php
$table_name = "passwordEncryption";
$alert = "";

include('controller/select.php');
include("includes/header.php");
?>

<style>
.source, .target{
	background: #f1f1f1;
    margin: 5px;
    padding-bottom: 20px;
    border-radius: 4px;
}

.source-heading, .target-heading{
	margin: 20px 5px 10px 5px;
}

</style>


<div class="page-wrapper">
	<div class="content container-fluid">
	  
	   <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Code Level Password Encryption</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-2">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Code Level Password Encryption</li>
					</ol>
					<button class="btn btn-danger float-right veiwbutton ml-3" onclick="getForm('addSSH')">
					    <i class="fa fa-plus-circle"></i> New Connection
					</button>
					<!--<button class="btn btn-primary float-right veiwbutton ml-3" onclick="AddOrDeleteServerUserForm('ServerUser')">Add / Remove User</button>-->
				</div>
			</div>
		</div>
		
		<div class="page-header">
			<div class="row">
			  <div class="col-12">
				<?php echo $alert; ?>
			  </div>
			</div>
			
			<div class="row">
			   <div class="col-sm-12">
				  <div class="card card-table">
					 <div class="card-body booking_card">
						<div class="table-responsive">
							<table class="datatable table table-stripped table table-hover table-center mb-0">
								<thead>
									<tr>
										<th>#</th>
										<th>Source Server </th>
										<th>Source IP </th>
										<th>Source User </th>
										<th>Source Account </th>
										<th>Target Server </th>
										<th>Target User </th>
										<th>Created On</th>
										<th>Key</th>
										<!--<th>Status</th>
										<th class="text-right">Actions</th>
										-->
									</tr>
								</thead>
								<tbody>
								 <?php
								  foreach( $result as $key=>$row ) { ?>
									<tr>
									    <td><?=++$key?></td>
										<td class="text-lowercase"><?=$row["sServer"]?></td>
										<td><?=$row["sIP"]?></td>
										<td class="text-lowercase"><?=$row["sUser"]?></td>
										<td>
										  <?php if($row["source_account_type"] == 1) echo "Service";?>
										  <?php if($row["source_account_type"] == 2) echo "Funnctional";?>
										  <?php if($row["source_account_type"] == 3) echo "Local";?>
										</td>
										<td class="text-lowercase"><?=$row["tServer"]?></td>
										<td class="text-lowercase"><?=$row["tUser"]?></td>
										<td><?=date('d-M-Y', strtotime($row["created_at"]))?></td>
										<td>
										  <button class="btn btn-status p-0" onclick="getPeKey('<?=$row["peId"]?>')">
											<i class="fa fa-eye text-info"></i> View
										  </button>
										</td>
										<!--
										<td>
										   <button type="submit" class="btn <?php echo $row["status"] == 1 ? 'btn-success' : 'btn-secondary' ?>" onclick="updateStatusOnDB('<?=$row["id"]?>','dS','<?=$row["status"]?>')">
											   <?php echo $row["status"] == 1 ? 'Active' : 'Inactive' ?>
										  </button>
										</td>
									
										<td class="text-right">
											<div class="dropdown dropdown-action">
											  <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											   <i class="fa fa-ellipsis-v ellipse_color"></i>
											  </a>
											  
											  <div class="dropdown-menu dropdown-menu-right">
												  
												  <button class="dropdown-item" href="#" onclick="editForm('<?=$row["id"]?>','dS')">
													<i class="fa fa-pencil-square-o m-r-5 text-primary"></i> Edit Server
												  </button>
												  
												  <button class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_asset" onclick="deleteOnDB('<?=$row["id"]?>','<?=$row["host_name"]?>','dS')">
												   <i class="fa fa-trash-o m-r-5 text-danger"></i> Delete Server
												  </button>
												  
												  <button class="dropdown-item" onclick="AssigneOrDeleteForm('<?=$row["id"]?>','ServerUser')">
												   <i class="fa fa-plug m-r-5 text-warning"></i>Add / Remove User
												  </button>
												
												</div>
											   </div>
										    </td>
											-->
										</tr>
									 <?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				 </div>
			 </div>
		  </div>
	  </div>
   </div>
</div>


	
<!-- Modal's -->
 <div id="getUserModal"></div>
 <div id="getFormModal"></div>
 <div id="getStatusModal"></div>
<!-- Model's -->


<!-- jQuery -->
<script>  
	var element = document.getElementById("passwordEncryption");
	   element.classList.add("active");
	  
</script>
<?php include("includes/footer.php"); ?>
	
