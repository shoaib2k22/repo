<?php

include('../../dbConnection.php');


switch($_REQUEST['key']) {
  case "dR":
    $table = 'roles';
	$id = $_REQUEST['id'];
	$name = getDetails($conn, $table, $id);
	deleted($conn, $table, $id, $name);
    break;
  case "dU":
    $table = 'users';
	$id = $_REQUEST['id'];
	$name = getDetails($conn, $table, $id);
	deleted($conn, $table, $id, $name);
    break;
  case "dA":
    $table = 'admins';
	$id = $_REQUEST['id'];
	$name = getDetails($conn, $table, $id);
	deleted($conn, $table, $id, $name);
    break;
  case "dM":
    $table = 'markets';
	$id = $_REQUEST['id'];
	$name = getDetails($conn, $table, $id);
	deleted($conn, $table, $id, $name);
    break;
  case "dO":
    $table = 'server_owners';
	$id = $_REQUEST['id'];
	$name = getDetails($conn, $table, $id);
	deleted($conn, $table, $id, $name);
    break;
  case "dS":
    $table = 'servers';
	$id = $_REQUEST['id'];
	$name = getDetails($conn, $table, $id);
	deleted($conn, $table, $id, $name);
    break;
  case "dSU":
    $table = 'server_users';
	$id = $_REQUEST['id'];
	$name = getDetails($conn, $table, $id);
	deleted($conn, $table, $id, $name);
    break;
  default:
    $table = '';
}

function getDetails($conn, $table, $id){
	 $sql = "SELECT * FROM $table WHERE id = $id";
	 $result = $conn->query($sql);
	 $row = mysqli_fetch_array($result);
	 if($table == 'roles'){ return $row['role']; }
	 if($table == 'users'){ return $row['email']; }
	 if($table == 'admins'){ return $row['email']; }
	 if($table == 'markets'){ return $row['market']; }
	 if($table == 'server_owners'){ return $row['email']; }
	 if($table == 'servers'){ return $row['host_name']; }
	 if($table == 'server_users'){ return $row['user']; }
}
 

function deleted($conn, $table, $id, $name){
	
	$sql = "DELETE FROM $table WHERE id = $id";
	
	if($conn->query($sql) === TRUE) {
		error_log("Deleted existing ".substr($table, 0, -1)." ".$name." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
		$myObj = new stdClass();
		$myObj->code = 200;
		$myObj->text = "Deleted Successfully";
		$myObj->msg = "success";
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
		
	} else {
		error_log("Failed to delete existing ".substr($table, 0, -1)." ".$name." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
		$myObj = new stdClass();
		$myObj->code = 200;
		$myObj->text = "Somthing Went Wrong";
		$myObj->msg = "info";
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
		//echo "Error: " . $sql . "<br>" . $conn->error;
	}
   $conn->close();
}




/*
if(isset($_REQUEST['delete'])){
	
		$id = $_REQUEST['id'];
		
		$sql = 'DELETE FROM '.$table_name.' WHERE ID=:id';
		
		$parse = oci_parse($conn, $sql);
		
		
		oci_bind_by_name($parse, ':id', $id);
		
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Deleted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
}
*/

?>



<?php
/* if($msg == 1){?>
	 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<button type="button" class="close" data-dismiss="modal" onclick="reload()">&times;</button>
					<img src="assets/img/sent.png" alt="" width="50" height="46">
					<h3 class="delete_class">Deleted Successfully</h3>
					<div class="m-t-20"> 
						<a href="#" class="btn btn-white" data-dismiss="modal" onclick="reload()">Close</a>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php }  ?>




<?php
if($msg == 2){?>
	 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<img src="assets/img/sent.png" alt="" width="50" height="46">
					<h3 class="delete_class">Unable to delete</h3>
					<div class="m-t-20"> 
						<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php } */?>