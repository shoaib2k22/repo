<?php

include('../../dbConnection.php');


if($_REQUEST['key']=='RoleGrant'){

	if(!isset($_REQUEST['role']) || ($_REQUEST['uID'] == '') || ($_REQUEST['uMID'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->role = !isset($_REQUEST['role'])? "Role is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$user_id = $_REQUEST['uID'];
		$market_id = $_REQUEST['uMID'];
		$role_id = $_REQUEST['role'];
		$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_grant = "SELECT * FROM grants WHERE user_id = $user_id AND market_id = $market_id AND role_id = $role_id";
		 $result_check_grant = $conn->query($sql_check_grant);
		 $myObj->role = mysqli_num_rows($result_check_grant)== 0 ? "This Role is not assigned to this user" : "";
		 
		if($myObj->role != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
	    $sql = "DELETE FROM grants WHERE user_id = $user_id AND market_id = $market_id AND role_id = $role_id";
		
		if($conn->query($sql) === TRUE) {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Deleted Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}
         $conn->close();
	 }
} 



if($_REQUEST['key']=='ServerGrant'){
	
	if(!isset($_REQUEST['server']) || ($_REQUEST['uID'] == '') || ($_REQUEST['uMID'] == '')){
		
		$myObj = new stdClass();
		$myObj->host = !isset($_REQUEST['server'])? "Server is required" : "";
		//$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$user_id = $_REQUEST['uID'];
		$market_id = $_REQUEST['uMID'];
		$server_id = $_REQUEST['server'];
		//$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_grant = "SELECT * FROM grants WHERE user_id = $user_id AND market_id = $market_id AND server_id = $server_id";
		 $result_check_grant = $conn->query($sql_check_grant);
		 $myObj->host = mysqli_num_rows($result_check_grant)== 0 ? "This server is not assigned to this user" : "";
		 
		if($myObj->host != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
	    $sql = "DELETE FROM grants WHERE user_id = $user_id AND market_id = $market_id AND server_id = $server_id";
		
		if($conn->query($sql) === TRUE) {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Deleted Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}
         $conn->close();
	 }
} 



if($_REQUEST['key']=='Connect'){
	
	if(!isset($_REQUEST['server']) || ($_REQUEST['rID'] == '') || ($_REQUEST['rMID'] == '')){
		
		$myObj = new stdClass();
		$myObj->host = !isset($_REQUEST['server'])? "Server is required" : "";
		//$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$role_id = $_REQUEST['rID'];
		$market_id = $_REQUEST['rMID'];
		$server_id = $_REQUEST['server'];
		//$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_connects = "SELECT * FROM connects WHERE role_id = $role_id AND market_id = $market_id AND server_id = $server_id";
		 $result_check_connects = $conn->query($sql_check_connects);
		 $myObj->host = mysqli_num_rows($result_check_connects)==0 ? "This Server is not assigned to this role" : "";
		 
		if($myObj->host != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
	    $sql = "Delete FROM connects WHERE role_id = $role_id AND market_id = $market_id AND server_id = $server_id";
		
		if($conn->query($sql) === TRUE) {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Deleted Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
       $conn->close();
	}
} 


if($_REQUEST['key']=='UserServer'){
	
	if(!isset($_REQUEST['server']) || !isset($_REQUEST['user']) || ($_REQUEST['userName'] == '') || ($_REQUEST['ticket'] == '') || !isset($_REQUEST['action'])){
		
		$myObj = new stdClass();
		$myObj->host = !isset($_REQUEST['server'])? "Server is required" : "";
		$myObj->user = !isset($_REQUEST['user'])? "User is required" : "";
		$myObj->userName = $_REQUEST['userName'] == '' ? "User name is required" : "";
		//$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->action = !isset($_REQUEST['action']) ? "Action is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$sID = $_REQUEST['server'];
		$uID = $_REQUEST['user'];
		$userName = trim($_REQUEST['userName']);
		//$status = $_REQUEST['status'];
		$pass = rand(111111, 999999);
		
		$myObj = new stdClass();
		
		$sql_check_connects = "SELECT * FROM server_users WHERE server_id = $sID AND user_id = $uID AND user = '$userName'";
		 $result_check_connects = $conn->query($sql_check_connects);
		 $myObj->host = mysqli_num_rows($result_check_connects)==0 ? "This Server is not assigned to selected user" : "";
		 
		if($myObj->host != ''){
			$myObj->user = $myObj->host;
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
	    $sql = "DELETE FROM server_users WHERE server_id = $sID AND user_id = $uID";
		
		if($conn->query($sql) === TRUE) {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Deleted Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
       $conn->close();
	}
} 




/*
if(isset($_REQUEST['delete'])){
	
		$id = $_REQUEST['id'];
		
		$sql = 'DELETE FROM '.$table_name.' WHERE ID=:id';
		
		$parse = oci_parse($conn, $sql);
		
		
		oci_bind_by_name($parse, ':id', $id);
		
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Deleted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
}
*/

?>
