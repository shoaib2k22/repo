<?php
include('../../dbConnection.php');


if($_REQUEST['key']=='insertAdmin'){
	
	if(($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['mobile'] == '') || !isset($_REQUEST['status']) || !isset($_REQUEST['market'])){
		
		$myObj = new stdClass();
		$myObj->f_name = $_REQUEST['f_name']=='' ? "First name is required" : "";
		$myObj->l_name = $_REQUEST['l_name']=='' ? "Last name is required" : "";
		$myObj->email =  $_REQUEST['email']==''  ? "Email is required" : "";
		$myObj->mobile = $_REQUEST['mobile']=='' ? "Mobile is required" : "";
		$myObj->market = !isset($_REQUEST['market']) ? "Market is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$f_name = strtolower(trim($_REQUEST['f_name']));
		$l_name = strtolower(trim($_REQUEST['l_name']));
		$email = strtolower(trim($_REQUEST['email']));
		$mobile = strtolower(trim($_REQUEST['mobile']));
		//$pass = password_hash(rand (100000,999999), PASSWORD_DEFAULT);
		$pass = password_hash(123, PASSWORD_DEFAULT);
		$status = strtolower(trim($_REQUEST['status']));
		$market = strtolower(trim($_REQUEST['market']));
		
		
		$myObj = new stdClass();
		
		$sql_check_email = "SELECT email FROM admins WHERE email = '$email'";
		 $result_check_email = $conn->query($sql_check_email);
		 $myObj->email = mysqli_num_rows($result_check_email)>=1 ? "This email is already exist" : "";
		 
		$sql_check_mobile = "SELECT mobile FROM admins WHERE mobile = '$mobile'";
		 $result_check_mobile = $conn->query($sql_check_mobile);
		 $myObj->mobile = mysqli_num_rows($result_check_mobile)>=1 ? "This mobile is already exist" : "";
		 
		 if($myObj->mobile != '' || $myObj->email != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		$sql = "INSERT INTO admins (f_name, l_name, email, mobile, password, market_id, status) VALUES('$f_name', '$l_name', '$email', '$mobile', '$pass', $market, '$status')";
		
		if($conn->query($sql) === TRUE) {
			error_log("Added new admin ".$email." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
			error_log("Failed to add new admin ".$email." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 



if($_REQUEST['key']=='insertRole'){
	
	if(($_REQUEST['role'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->role = $_REQUEST['role']=='' ? "Role is required" : "";
		//$myObj->market = !isset($_REQUEST['market']) ? "Market is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$role = strtolower(trim($_REQUEST['role']));
		$market = 1;
		$status = strtolower(trim($_REQUEST['status']));
		
		$myObj = new stdClass();
		
		$sql_check_role = "SELECT role FROM roles WHERE role = '$role' AND market_id = '$market'";
		 $result_check_role = $conn->query($sql_check_role);
		 $myObj->role = mysqli_num_rows($result_check_role)>=1 ? "This Role is already exist" : "";
		 
		if($myObj->role != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		$sql = "INSERT INTO roles (role, market_id, status) VALUES('$role', $market, '$status')";
		
		if($conn->query($sql) === TRUE) {
			error_log("Added new role ".$role." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
			error_log("Failed to add new role ".$role." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 



if($_REQUEST['key']=='insertGrant'){
	
	if(!isset($_REQUEST['role']) || ($_REQUEST['uID'] == '') || ($_REQUEST['uMID'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->role = !isset($_REQUEST['role'])? "Role is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$user_id = strtolower(trim($_REQUEST['uID']));
		$market_id = strtolower(trim($_REQUEST['uMID']));
		$role_id = strtolower(trim($_REQUEST['role']));
		$status = strtolower(trim($_REQUEST['status']));
		
		$myObj = new stdClass();
		
		$sql_check_grant = "SELECT * FROM grants WHERE user_id = $user_id AND market_id = $market_id AND role_id = $role_id";
		 $result_check_grant = $conn->query($sql_check_grant);
		 $myObj->role = mysqli_num_rows($result_check_grant)>=1 ? "This Role is already assigned to this user" : "";
		 
		if($myObj->role != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
	    $sql = "INSERT INTO grants (user_id, role_id, market_id, status) VALUES($user_id, $role_id, $market_id, $status)";
		
		if($conn->query($sql) === TRUE) {
			error_log("Granted role ".$role_id." to ".$user_id." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
			error_log("Failed to grant role ".$role_id." to ".$user_id." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	 $conn->close();
	}
} 




if($_REQUEST['key']=='insertConnects'){
	
	if(!isset($_REQUEST['server']) || ($_REQUEST['rID'] == '') || ($_REQUEST['rMID'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->host = !isset($_REQUEST['server'])? "Server is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$role_id = $_REQUEST['rID'];
		$market_id = $_REQUEST['rMID'];
		$server_id = $_REQUEST['server'];
		$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_connects = "SELECT * FROM connects WHERE role_id = $role_id AND market_id = $market_id AND server_id = $server_id";
		 $result_check_connects = $conn->query($sql_check_connects);
		 $myObj->host = mysqli_num_rows($result_check_connects)>=1 ? "This Server is already assigned to this role" : "";
		 
		if($myObj->host != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
	    $sql = "INSERT INTO connects (role_id, server_id, market_id, status) VALUES($role_id, $server_id, $market_id, $status)";
		
		if($conn->query($sql) === TRUE) {
			error_log("Added server ".$server_id." on role ".$role_id." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
			error_log("Failed to add server ".$server_id." on role ".$role_id." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 


if($_REQUEST['key']=='insertServerUser'){
	
	if(($_REQUEST['user'] == '') || ($_REQUEST['sID'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->user = $_REQUEST['user'] == '' ? "User is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$server_id = strtolower(trim($_REQUEST['sID']));
		$user = strtolower(trim($_REQUEST['user']));
		$status = strtolower(trim($_REQUEST['status']));
		
		$myObj = new stdClass();
		
		$sql_check_users = "SELECT * FROM server_users WHERE user = '$user' AND server_id = $server_id";
		 $result_check_users = $conn->query($sql_check_users);
		 $myObj->user = mysqli_num_rows($result_check_users)>=1 ? "This User is already exists to this Server" : "";
		 
		if($myObj->user != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
	    $sql = "INSERT INTO server_users (user, server_id, status) VALUES('$user', $server_id, $status)";
		
		if($conn->query($sql) === TRUE) {
			error_log("Added new ServerUser ".$user." on server ".$server_id." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
			error_log("Failed to add new ServerUser ".$user." on server ".$server_id." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 



if($_REQUEST['key']=='insertMarket'){
	
	if(($_REQUEST['market'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->market = $_REQUEST['market']=='' ? "Market is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$market = strtolower(trim($_REQUEST['market']));
		$status = strtolower(trim($_REQUEST['status']));
		
		$myObj = new stdClass();
		
		$sql_check_market = "SELECT market FROM markets WHERE market = '$market'";
		 $result_check_market = $conn->query($sql_check_market);
		 $myObj->market = mysqli_num_rows($result_check_market)>=1 ? "This Market is already exist" : "";
		 
		if($myObj->market != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		$sql = "INSERT INTO markets (market, status) VALUES('$market', '$status')";
		
		if($conn->query($sql) === TRUE) {
			error_log("Added new market ".$market." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
			error_log("Failed to add new market ".$market." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	 $conn->close();
	}
} 



if($_REQUEST['key']=='insertOwner'){
	
	if(($_REQUEST['owner'] == '') || ($_REQUEST['email'] == '') || !isset($_REQUEST['market']) || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->owner = $_REQUEST['owner']=='' ? "Owner name is required" : "";
		$myObj->email =  $_REQUEST['email']==''  ? "Email is required" : "";
		$myObj->market = !isset($_REQUEST['market']) ? "Market is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$owner = strtolower(trim($_REQUEST['owner']));
		$email = strtolower(trim($_REQUEST['email']));
		$market = strtolower(trim($_REQUEST['market']));
		$status = strtolower(trim($_REQUEST['status']));
		
		$myObj = new stdClass();
		
		$sql_check_email = "SELECT email FROM server_owners WHERE email = '$email'";
		 $result_check_email = $conn->query($sql_check_email);
		 $myObj->email = mysqli_num_rows($result_check_email)>=1 ? "This Email is already exist" : "";
		 
		if($myObj->email != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		$sql = "INSERT INTO server_owners (owner, email, market_id, status) VALUES('$owner', '$email', $market, '$status')";
		
		if($conn->query($sql) === TRUE) {
			error_log("Added new ServerOwner ".$email." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
			error_log("Failed to add new ServerOwner ".$email." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 


if($_REQUEST['key']=='insertServer'){
	
	if(($_REQUEST['ticket'] == '') || ($_REQUEST['host'] == '') || ($_REQUEST['ip'] == '')){
		
		$myObj = new stdClass();
		$myObj->host = $_REQUEST['host']=='' ? "Host name is required" : "";
		$myObj->ip =  $_REQUEST['ip']==''  ? "Ip is required" : "";
		//$myObj->os_type =  $_REQUEST['os_type']==''  ? "Os Type is required" : "";
		//$myObj->port =  $_REQUEST['port']==''  ? "Port is required" : "";
		//$myObj->password =  $_REQUEST['password']==''  ? "Password is required" : "";
		//$myObj->owner = !isset($_REQUEST['owner']) ? "Owner is required" : "";
		//$myObj->market = !isset($_REQUEST['market']) ? "Market is required" : "";
		//$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		//$owner_id = $_REQUEST['owner'];
		$host = strtolower(trim($_REQUEST['host']));
		$ip = strtolower(trim($_REQUEST['ip']));
		$market = 1;
		//$port = $_REQUEST['port'];
		//$os_type = $_REQUEST['os_type'];
		//$pass = $_REQUEST['password'];
		//$secure_key = substr(md5(time()), 0, 10);
		//include('encrypt.php');
		//$password = encrypt($pass,$secure_key);
		//$status = $_REQUEST['status'];
		//$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_host = "SELECT host_name FROM servers WHERE host_name = '$host'";
		 $result_check_host = $conn->query($sql_check_host);
		 $myObj->host = mysqli_num_rows($result_check_host)>=1 ? "This Server name is already exist" : "";
		 
		$sql_check_ip = "SELECT ip_address FROM servers WHERE ip_address = '$ip'";
		 $result_check_ip = $conn->query($sql_check_ip);
		 $myObj->ip = mysqli_num_rows($result_check_ip)>=1 ? "This IP adderss is already exist" : "";
		 
		 if($myObj->host != '' || $myObj->ip != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		
		$sql = "INSERT INTO servers (host_name, ip_address, market_id) VALUES('$host', '$ip', $market)";
		
		if($conn->query($sql) === TRUE) {
			error_log("Added new server ".$host." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
			error_log("Failed to add new server ".$host." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 



if($_REQUEST['key']=='insertUser'){
	
	if(($_REQUEST['ticket'] == '') || ($_REQUEST['unix_id'] == '') || ($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '')){
		
		$myObj = new stdClass();
		$myObj->ticket =  $_REQUEST['ticket']=='' ? "Ticket No. is required" : "";
		$myObj->unix =  $_REQUEST['unix_id']=='' ? "Unix Id is required" : "";
		$myObj->f_name = $_REQUEST['f_name']=='' ? "First name is required" : "";
		$myObj->l_name =  $_REQUEST['l_name']=='' ? "Last Name is required" : "";
		$myObj->email = $_REQUEST['email']=='' ? "Email is required" : "";
		//$myObj->mobile = !isset($_REQUEST['mobile']) ? "Mobile is required" : "";
		//$myObj->market = !isset($_REQUEST['market']) ? "Market is required" : "";
		//$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		//$myObj->gender = !isset($_REQUEST['gender']) ? "Gender is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$ticket = strtolower(trim($_REQUEST['ticket']));
		$unix_id = strtolower(trim($_REQUEST['unix_id']));
		$f_name = strtolower(trim($_REQUEST['f_name']));
		$l_name = strtolower(trim($_REQUEST['l_name']));
		$email = strtolower(trim($_REQUEST['email']));
		//$mobile = $_REQUEST['mobile'];
		$market_id = 1;
		//$status = $_REQUEST['status'];
		//$gender = $_REQUEST['gender'];
		//$password = rand (100,999);
		$password = password_hash(rand (100000,999999), PASSWORD_DEFAULT);
		$assignedServer = $_REQUEST['assignedServer'];
		$assignedUser = $_REQUEST['assignedUser'];
		$assignedRole = $_REQUEST['assignedRole'];
		
		$myObj = new stdClass();
		
		$sql_check_email = "SELECT email FROM users WHERE email = '$email'";
		 $result_check_email = $conn->query($sql_check_email);
		 $myObj->email = mysqli_num_rows($result_check_email)>=1 ? "This email is already exist" : "";
		 
		/* $sql_check_mobile = "SELECT mobile FROM users WHERE mobile = '$mobile'";
		 $result_check_mobile = $conn->query($sql_check_mobile);
		 $myObj->mobile = mysqli_num_rows($result_check_mobile)>=1 ? "This mobile is already exist" : ""; */
		 
		 if($myObj->email != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		$sql = "INSERT INTO users (unix_id, market_id, f_name, l_name, email, password) VALUES('$unix_id', '$market_id','$f_name', '$l_name', '$email', '$password')";
		
		
		if($conn->query($sql) === TRUE) {
			error_log("Added new user ".$email." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
			
			$current_user_id = $conn->insert_id;
			
			if($assignedServer!='' && $assignedUser!=''){
				$sql_server = "INSERT INTO grants (user_id, server_id, server_user_id, market_id) VALUES($current_user_id, $assignedServer, $assignedUser, $market_id)";
				$conn->query($sql_server);
			}
			
			if($assignedRole!=''){
				$sql_role = "INSERT INTO grants (user_id, role_id, market_id, status) VALUES($current_user_id, $assignedRole, $market_id, 1)";
				$conn->query($sql_role);
			}
			
			include('mail.php');
			
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
			error_log("Failed to add new user ".$email." on ".date('d-m-Y H:i:s')."\n", 3, "../../audit_logs/actions.log");
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
      $conn->close();
	}
} 

?>
