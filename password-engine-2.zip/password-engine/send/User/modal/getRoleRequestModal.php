<?php
include('../../dbConnection.php');

$uEmail = $_SESSION['uEmail'];

$user_id=$_POST['id'];


$sql_user = "SELECT users.id, users.market_id ,markets.market FROM users,markets WHERE users.id = $user_id AND users.email = '$uEmail' AND users.is_active = 1 AND markets.id = users.market_id";
  $result_user = $conn->query($sql_user);
  $row_emp = $result_user->fetch_assoc();
  $uMId = $row_emp['market_id'];
  


$sql_rg = "SELECT roles.id, roles.role FROM roles,grants WHERE grants.user_id = $user_id AND roles.id != grants.role_id AND roles.market_id = $uMId;";
  $result_rg = $conn->query($sql_rg);
  
  
  
//$sql_rgm = "SELECT roles.id, roles.role FROM roles,grants,markets WHERE roles.id != grants.role_id AND grants.user_id = $user_id AND grants.market_id = roles.market_id And grants.market_id = markets.id;";
  



	
	
?>

<div class="modal" id="getRoleRequestModal">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Request For New Role</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
     <!-- Modal Header end-->
	 
	 
     <!-- Modal body -->
      <div class="modal-body">
	     <form action="" method="POST" id="roleRequestForm">
			<div class="form-group">
			  <label>Market</label>
			  <input type="hidden" class="form-control" name="uId" value="<?php echo $row_emp['id']; ?>" readonly>
			  <input type="text" class="form-control" name="market" value="<?php echo $row_emp['market']; ?>" readonly>
			</div>
			
			<div class="form-group">
			  <label>Select Role</label>
			  <select class="form-control" name="rId" onchange="getSendRRButton()">
				<option value="" disabled selected>Select Role</option>
				  <?php while($row_rg = $result_rg->fetch_assoc()){ ?>  
					<option value="<?php echo $row_rg['id']; ?>"> <?php echo $row_rg['role']; ?> </option>  
				  <?php }?>
			  </select>
			</div>
		  </form>
      </div> 
	  <!-- Modal body end-->
	  
	  <!-- Modal Footer -->
	  <div class="modal-footer float-right">
	     <button type="button" class="btn btn-primary" id="sendRRModal" onclick="sendRoleRequestModal()">Request</button>
	     <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
	  </div>
	  <!-- Modal Footer end-->
      
    </div>
   </div>
 </div>