<?php

include('../dbConnection.php');

   if(!isset($_SESSION['is_user_login'])){
	  
	  if(isset($_REQUEST['uEmail'])){
			$uEmail = mysqli_real_escape_string($conn,trim($_REQUEST['uEmail']));
			$uPassword = mysqli_real_escape_string($conn,trim($_REQUEST['uPassword']));
			$sql = "SELECT email, password FROM users WHERE email='".$uEmail."' AND is_active = 1 AND is_deleted = 0 limit 1";
			$result = $conn->query($sql);
		
		if($result->num_rows == 1){
			$row = $result->fetch_assoc();
			
			if(password_verify($uPassword, $row['password'])){
				$_SESSION['is_user_login'] = true;
			    $_SESSION['uEmail'] = $uEmail;
			    error_log("Successfully logged in by user ".$uEmail." at ".date('d-m-Y H:i:s')."\n", 3, "../audit_logs/userLogin.log");
			    // Redirecting to RequesterProfile page on Correct Email and Pass
			    echo "<script> location.href='dashboard.php'; </script>";
			    exit;
			}
			else{
			  error_log("Unsuccessful login attempt by user ".$uEmail." due to using invalid password at ".date('d-m-Y H:i:s')."\n", 3, "../audit_logs/userLogin.log");
			  $msg = '<div class="alert alert-warning mt-2" role="alert"> Enter Valid Password </div>';
		    }
		}
        else{
			  error_log("Unsuccessful login attempt by user ".$uEmail." due to using invalid Email & Password at ".date('d-m-Y H:i:s')."\n", 3, "../audit_logs/userLogin.log");
			  $msg = '<div class="alert alert-warning mt-2" role="alert"> Enter Valid Email & Password</div>';
		  }		
	  }
	  
	}
	elseif($_SESSION['is_user_login']==1){
		 
		 // Redirecting to RequesterProfile page on Correct Email and Pass
		 echo "<script> location.href='dashboard.php'; </script>";
		 exit;
	}
	else {
	  echo "oooo";
	  exit;
	  echo "<script> location.href='index.php'; </script>";
    }

?>