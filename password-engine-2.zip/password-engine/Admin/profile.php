<?php
$table_name = "profile";
$alert = "";

include('controller/select.php');
include("includes/header.php");

?>

<div class="page-wrapper">
	<div class="content container-fluid">
	
	  <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Profile</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Profile</li>
					</ol>
				</div>
			</div>
		</div>

		<div class="col-sm-6 mb-5">
		  <div class="card mt-5 mx-5">
		   <div class="card-header"><?=$admin; ?> Profile</div>
		   <div class="card-body">
			   <h5 class="card-title text-capitalize"><?=$aFName.' '.$aLName; ?></h5>
			   <h6 class="card-text"><?=$aEmail; ?></h6>
			   <p class="card-text">Market: <span class="text-uppercase"><?=$admin_market; ?></span></p>
			   <p class="card-text">Assigned At: <?=date("d-M-Y",strtotime($aCA)); ?></p>
			   <div class="float-right invisible">
				   <button class="btn btn-danger mr-3" onclick="show()">View</button>
				   <button class="btn btn-secondary" onclick="hide()">Close</button>
			   </div>
		   </div>
		   </div>  
		</div>
		
	</div>
</div>


<?php include("includes/footer.php"); ?>