<?php
$table_name = "server_owners";
$alert = "";

include('controller/select.php');
include("includes/header.php");

?>

<style>


#selectColumn .table td, #selectColumn .table th {
    padding: 0.5rem;
    vertical-align: middle;
    border-top: 1px solid #dee2e6;
}

.toggle-group-custom{
	border: 1px solid #d3caca94;
	display:flex;
    justify-content: space-between;
    padding: 5px 8px;
    border-radius: 3px;
    line-height: 33px;
    font-size: 16px;
}

.btn-group-xs>.btn,.btn-xs{padding:.35rem .4rem .25rem .4rem;font-size:.875rem;line-height:.5;border-radius:.2rem}.checkbox label .toggle,.checkbox-inline .toggle{margin-left:-1.25rem;margin-right:.35rem}.toggle{position:relative;overflow:hidden}.toggle.btn.btn-light,.toggle.btn.btn-outline-light{border-color:rgba(0,0,0,.15)}.toggle input[type=checkbox]{display:none}.toggle-group{position:absolute;width:200%;top:0;bottom:0;left:0;transition:left .35s;-webkit-transition:left .35s;-moz-user-select:none;-webkit-user-select:none}.toggle-group label,.toggle-group span{cursor:pointer}.toggle.off .toggle-group{left:-100%}.toggle-on{position:absolute;top:0;bottom:0;left:0;right:50%;margin:0;border:0;border-radius:0}.toggle-off{position:absolute;top:0;bottom:0;left:50%;right:0;margin:0;border:0;border-radius:0;box-shadow:none}.toggle-handle{position:relative;margin:0 auto;padding-top:0;padding-bottom:0;height:100%;width:0;border-width:0 1px;background-color:#fff}.toggle.btn-outline-primary .toggle-handle{background-color:var(--primary);border-color:var(--primary)}.toggle.btn-outline-secondary .toggle-handle{background-color:var(--secondary);border-color:var(--secondary)}.toggle.btn-outline-success .toggle-handle{background-color:var(--success);border-color:var(--success)}.toggle.btn-outline-danger .toggle-handle{background-color:var(--danger);border-color:var(--danger)}.toggle.btn-outline-warning .toggle-handle{background-color:var(--warning);border-color:var(--warning)}.toggle.btn-outline-info .toggle-handle{background-color:var(--info);border-color:var(--info)}.toggle.btn-outline-light .toggle-handle{background-color:var(--light);border-color:var(--light)}.toggle.btn-outline-dark .toggle-handle{background-color:var(--dark);border-color:var(--dark)}.toggle[class*=btn-outline]:hover .toggle-handle{background-color:var(--light);opacity:.5}.toggle.btn{min-width:3.7rem;min-height:2.15rem}.toggle-on.btn{padding-right:1.5rem}.toggle-off.btn{padding-left:1.5rem}.toggle.btn-lg{min-width:5rem;min-height:2.815rem}.toggle-on.btn-lg{padding-right:2rem}.toggle-off.btn-lg{padding-left:2rem}.toggle-handle.btn-lg{width:2.5rem}.toggle.btn-sm{min-width:3.125rem;min-height:1.938rem}.toggle-on.btn-sm{padding-right:1rem}.toggle-off.btn-sm{padding-left:1rem}.toggle.btn-xs{min-width:2.19rem;min-height:1.375rem}.toggle-on.btn-xs{padding-right:.8rem}.toggle-off.btn-xs{padding-left:.8rem}
</style>


<div class="page-wrapper">
	<div class="content container-fluid">
	   
	   <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Server Users</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Server Users</li>
					</ol>
					<button class="btn btn-danger float-right veiwbutton ml-3" onclick="AddOrDeleteServerUserForm('ServerUser')">Add / Remove User</button>
					<button class="btn btn-primary float-right veiwbutton ml-3" onclick="seheduleJob();">Schedule Job</button>
					<a class="cursor-pointer float-right ml-3" data-toggle="modal" data-target="#selectColumn"><i class="fa fa-columns"></i></a>
				</div>
			</div>
		</div>
	
		<div class="page-header">
			<div class="row">
			  <div class="col-12">
				<?php echo $alert; ?>
			  </div>
			</div>
			
			<div class="row">
			   <div class="col-sm-12">
				  <div class="card card-table">
					<div class="card-body booking_card">
						<div class="table-responsive">
						   <table class="datatable table table-stripped table table-hover table-center mb-0">
						        <thead>
								    <tr>
										<th>#</th>
										<th>Server User</th>
										<th>Server Owner</th>
										<th>Server Name</th>
										<th>Market</th>
										<th>Status</th>
										<th>Last Password Changed</th>
										<th>Period</th>
										<th>Created On</th>
										<!--<th>View</th>-->
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tbody>
								 <?php
								  foreach( $result as $key=>$row ){ ?>
									<tr>
										<td><?=++$key?></td>
										<td class="text-lowercase"><?=$row["user"]?></td>
										<td>
										   <h6 class="text-capitalize font-weight-light m-0"><?=$row["f_name"]." ".$row["l_name"]?></h6>
										   <?=$row["email"];?>
										</td>
										<td class="text-lowercase"><?=$row["host_name"]?></td>
										<td class="text-capitalize"><?=$row["market"]?></td>
										<!--
										<td>
										   <button type="submit" class="btn btn-status <?php echo $row["status"] == 1 ? 'btn-success' : 'btn-secondary' ?>" onclick="updateStatusOnDB('<?=$row["id"]?>','dO','<?=$row["status"]?>')">
											   <?php echo $row["status"] == 1 ? 'Active' : 'Inactive' ?>
										   </button>
										</td>
										-->
										
										<td class="text-center">
										 <?php 
										   if($row["status"] == 0) 
											     echo '<button class="btn btn-warning btn-status">Pending</button>';
										   
										   if($row["status"] == 1) 
											     echo '<button class="btn btn-success btn-status">Active</button>';
										   
										   if($row["status"] == 2) 
											     echo '<button class="btn btn-danger btn-status">Declined</button>';
										 ?>
									    </td>
										
										<td class="text-center">
										  <?php
										    if($row["last_password_changed"] == null){
												echo "----";
											}
											else{
												echo date('d-M-Y', strtotime($row["last_password_changed"]));
											}
										  ?>
										</td>
										
										
										<td class="text-center"><?php echo isset($row["password_rotation_period"]) ? $row["password_rotation_period"]." Days" : '----'; ?></td>
										
										<td><?=date('d-M-Y', strtotime($row["created_at"]))?></td>
										<!--
										<td>
											<button class="btn btn-warning" onclick="getServer('<?=$row["id"]?>', '<?=$row["owner"]?>')"><i class="fa fa-eye"></i></button>
										</td>
										-->
										<td class="text-right">
											<div class="dropdown dropdown-action d-inline">
											  <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											   <i class="fa fa-ellipsis-v ellipse_color"></i>
											  </a>
											  
											  <div class="dropdown-menu dropdown-menu-right">
												  
												  <button class="dropdown-item" onclick="editForm('<?=$row["id"]?>','dO')">
													<i class="fa fa-pencil-square-o m-r-5 text-primary"></i> Edit User 
												  </button>
												  
												  <button class="dropdown-item" data-toggle="modal" data-target="#delete_asset" onclick="deleteOnDB('<?=$row["id"]?>','<?=$row["user"]?>','dSU')">
												   <i class="fa fa-trash-o m-r-5 text-danger"></i> Delete User
												  </button>
											   </div>
											  </div>
										 </td>
									 </tr>
								   <?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			 </div>
		  </div>
	   </div>
    </div>
</div>
	
	
<!-- Modal's -->
 <div id="getServerModal"></div>
 <div id="getFormModal"></div>
 <div id="getStatusModal"></div>
<!-- Model's -->




<div class="modal fade delete-modal" id="selectColumn" data-keyboard="false" data-backdrop="static">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

			<!-- Modal Header -->
			<div class="modal-header">
				<h4 class="modal-title">Column Selection</h4>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>

			<!-- Modal body -->
			<div class="modal-body">
			    <form>
					<div class="row formtype">
						<div class="col-md-12">
							<div class="form-group toggle-group-custom">
								<span>Column 1</span>
								<input type="checkbox" checked="" data-toggle="toggle" data-style="slow">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group toggle-group-custom">
								<span>Column 1</span>
								<input type="checkbox" checked="" data-toggle="toggle" data-style="slow">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group toggle-group-custom">
								<span>Column 1</span>
								<input type="checkbox" checked="" data-toggle="toggle" data-style="slow">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group toggle-group-custom">
								<span>Column 1</span>
								<input type="checkbox" checked="" data-toggle="toggle" data-style="slow">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group toggle-group-custom">
								<span>Column 1</span>
								<input type="checkbox" checked="" data-toggle="toggle" data-style="slow">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group toggle-group-custom">
								<span>Column 1</span>
								<input type="checkbox" checked="" data-toggle="toggle" data-style="slow">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group toggle-group-custom">
								<span>Column 1</span>
								<input type="checkbox" checked="" data-toggle="toggle" data-style="slow">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group toggle-group-custom">
								<span>Column 1</span>
								<input type="checkbox" checked="" data-toggle="toggle" data-style="slow">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group toggle-group-custom">
								<span>Column 1</span>
								<input type="checkbox" checked="" data-toggle="toggle" data-style="slow">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group toggle-group-custom">
								<span>Column 1</span>
								<input type="checkbox" checked="" data-toggle="toggle" data-style="slow">
							</div>
						</div>
						
					</div>
				</form>
			</div>
			
		    <!-- Modal footer -->
			<div class="modal-footer float-right">
				  <button type="button" class="btn btn-danger">Save</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			</div>
						
		</div>
		 
	</div>
</div>
	 
	
	
<!-- jQuery -->
<script>
	var element = document.getElementById("ServerUser");
	   element.classList.add("active");
</script>

<script>
 function selectColumn(){
	 alert('hello');
 }

</script>


<?php include("includes/footer.php"); ?>

<script>
!function(a){"use strict";function l(t,e){this.$element=a(t),this.options=a.extend({},this.defaults(),e),this.render()}l.VERSION="3.6.0",l.DEFAULTS={on:"Show",off:"Hide",onstyle:"primary",offstyle:"light",size:"normal",style:"",width:null,height:null},l.prototype.defaults=function(){return{on:this.$element.attr("data-on")||l.DEFAULTS.on,off:this.$element.attr("data-off")||l.DEFAULTS.off,onstyle:this.$element.attr("data-onstyle")||l.DEFAULTS.onstyle,offstyle:this.$element.attr("data-offstyle")||l.DEFAULTS.offstyle,size:this.$element.attr("data-size")||l.DEFAULTS.size,style:this.$element.attr("data-style")||l.DEFAULTS.style,width:this.$element.attr("data-width")||l.DEFAULTS.width,height:this.$element.attr("data-height")||l.DEFAULTS.height}},l.prototype.render=function(){this._onstyle="btn-"+this.options.onstyle,this._offstyle="btn-"+this.options.offstyle;var t="large"===this.options.size||"lg"===this.options.size?"btn-lg":"small"===this.options.size||"sm"===this.options.size?"btn-sm":"mini"===this.options.size||"xs"===this.options.size?"btn-xs":"",e=a('<label for="'+this.$element.prop("id")+'" class="btn">').html(this.options.on).addClass(this._onstyle+" "+t),s=a('<label for="'+this.$element.prop("id")+'" class="btn">').html(this.options.off).addClass(this._offstyle+" "+t),o=a('<span class="toggle-handle btn btn-light">').addClass(t),i=a('<div class="toggle-group">').append(e,s,o),l=a('<div class="toggle btn" data-toggle="toggle" role="button">').addClass(this.$element.prop("checked")?this._onstyle:this._offstyle+" off").addClass(t).addClass(this.options.style);this.$element.wrap(l),a.extend(this,{$toggle:this.$element.parent(),$toggleOn:e,$toggleOff:s,$toggleGroup:i}),this.$toggle.append(i);var n=this.options.width||Math.max(e.outerWidth(),s.outerWidth())+o.outerWidth()/2,h=this.options.height||Math.max(e.outerHeight(),s.outerHeight());e.addClass("toggle-on"),s.addClass("toggle-off"),this.$toggle.css({width:n,height:h}),this.options.height&&(e.css("line-height",e.height()+"px"),s.css("line-height",s.height()+"px")),this.update(!0),this.trigger(!0)},l.prototype.toggle=function(){this.$element.prop("checked")?this.off():this.on()},l.prototype.on=function(t){if(this.$element.prop("disabled"))return!1;this.$toggle.removeClass(this._offstyle+" off").addClass(this._onstyle),this.$element.prop("checked",!0),t||this.trigger()},l.prototype.off=function(t){if(this.$element.prop("disabled"))return!1;this.$toggle.removeClass(this._onstyle).addClass(this._offstyle+" off"),this.$element.prop("checked",!1),t||this.trigger()},l.prototype.enable=function(){this.$toggle.removeClass("disabled"),this.$toggle.removeAttr("disabled"),this.$element.prop("disabled",!1)},l.prototype.disable=function(){this.$toggle.addClass("disabled"),this.$toggle.attr("disabled","disabled"),this.$element.prop("disabled",!0)},l.prototype.update=function(t){this.$element.prop("disabled")?this.disable():this.enable(),this.$element.prop("checked")?this.on(t):this.off(t)},l.prototype.trigger=function(t){this.$element.off("change.bs.toggle"),t||this.$element.change(),this.$element.on("change.bs.toggle",a.proxy(function(){this.update()},this))},l.prototype.destroy=function(){this.$element.off("change.bs.toggle"),this.$toggleGroup.remove(),this.$element.removeData("bs.toggle"),this.$element.unwrap()};var t=a.fn.bootstrapToggle;a.fn.bootstrapToggle=function(o){var i=Array.prototype.slice.call(arguments,1)[0];return this.each(function(){var t=a(this),e=t.data("bs.toggle"),s="object"==typeof o&&o;e||t.data("bs.toggle",e=new l(this,s)),"string"==typeof o&&e[o]&&"boolean"==typeof i?e[o](i):"string"==typeof o&&e[o]&&e[o]()})},a.fn.bootstrapToggle.Constructor=l,a.fn.toggle.noConflict=function(){return a.fn.bootstrapToggle=t,this},a(function(){a("input[type=checkbox][data-toggle^=toggle]").bootstrapToggle()}),a(document).on("click.bs.toggle","div[data-toggle^=toggle]",function(t){a(this).find("input[type=checkbox]").bootstrapToggle("toggle"),t.preventDefault()})}(jQuery);
//# sourceMappingURL=bootstrap4-toggle.min.js.map
</script>
	