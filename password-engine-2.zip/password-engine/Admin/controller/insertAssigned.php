<?php
include('../../dbConnection.php');


if($_REQUEST['key']=='RoleGrant'){
	
	if(!isset($_REQUEST['role']) || ($_REQUEST['uID'] == '') || ($_REQUEST['uMID'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->role = !isset($_REQUEST['role'])? "Role is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$user_id = $_REQUEST['uID'];
		$market_id = $_REQUEST['uMID'];
		$role_id = $_REQUEST['role'];
		$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_grant = "SELECT * FROM grants WHERE user_id = $user_id AND market_id = $market_id AND role_id = $role_id";
		 $result_check_grant = $conn->query($sql_check_grant);
		 $myObj->role = mysqli_num_rows($result_check_grant)>=1 ? "This role is already assigned to this user" : "";
		
		
		if($myObj->role != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
	    $sql = "INSERT INTO grants (user_id, role_id, market_id, status) VALUES($user_id, $role_id, $market_id, $status)";
		
		if($conn->query($sql) === TRUE) {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Assigned Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}
       $conn->close();
	}
} 



if($_REQUEST['key']=='ServerGrant'){
	
	if(!isset($_REQUEST['server']) || ($_REQUEST['uID'] == '') || ($_REQUEST['uMID'] == '') || !isset($_REQUEST['server_user'])){
		
		$myObj = new stdClass();
		$myObj->host = !isset($_REQUEST['server'])? "Server is required" : "";
		$myObj->ErrorUserName = !isset($_REQUEST['server_user']) ? "User is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$user_id = $_REQUEST['uID'];
		$market_id = $_REQUEST['uMID'];
		$server_id = $_REQUEST['server'];
		$server_user_id = $_REQUEST['server_user'];
		
		
		$myObj = new stdClass();
		
		$sql_check_grant = "SELECT * FROM grants WHERE user_id = $user_id AND market_id = $market_id AND server_id = $server_id";
		 $result_check_grant = $conn->query($sql_check_grant);
		 $myObj->host = mysqli_num_rows($result_check_grant)>=1 ? "This server is already assigned to this user" : "";
		
		
		if($myObj->host != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
	    $sql = "INSERT INTO grants (user_id, server_id, server_user_id, market_id) VALUES($user_id, $server_id, $server_user_id, $market_id)";
		
		
		$sql_user_owner = "SELECT * FROM server_users, servers, users WHERE server_users.user_id = users.id AND  server_users.server_id = servers.id AND server_users.id = $server_user_id";
		 $result_user_owner = $conn->query($sql_user_owner);
		 $row_user_owner = mysqli_fetch_assoc($result_user_owner);
		 $name_user_owner = $row_user_owner['f_name']." ".$row_user_owner['l_name'];
		 $email_user_owner = $row_user_owner['email'];
		 $userName = $row_user_owner['user'];
		 $serverName = $row_user_owner['host_name'];
		
		
		$sql_requester = "SELECT * FROM users WHERE id = $user_id";
		 $result_requester = $conn->query($sql_requester);
		 $row_requester = mysqli_fetch_assoc($result_requester);
		 $requesterName = $row_requester['f_name']." ".$row_requester['l_name'];
		 $requesterEmail = $row_requester['email'];
		
	
		if($conn->query($sql) === TRUE) {
			include('mail.php');
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Assigned Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}
       $conn->close();
	}
} 




if($_REQUEST['key']=='Connect'){
	
	if(!isset($_REQUEST['server']) || ($_REQUEST['rID'] == '') || ($_REQUEST['rMID'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->host = !isset($_REQUEST['server'])? "Server is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$role_id = $_REQUEST['rID'];
		$market_id = $_REQUEST['rMID'];
		$server_id = $_REQUEST['server'];
		$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_connects = "SELECT * FROM connects WHERE role_id = $role_id AND market_id = $market_id AND server_id = $server_id";
		 $result_check_connects = $conn->query($sql_check_connects);
		 $myObj->host = mysqli_num_rows($result_check_connects)>=1 ? "This Server is already assigned to this role" : "";
		 
		if($myObj->host != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
	    $sql = "INSERT INTO connects (role_id, server_id, market_id, status) VALUES($role_id, $server_id, $market_id, $status)";
		
		if($conn->query($sql) === TRUE) {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Assigned Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
       $conn->close();
	}
} 



if($_REQUEST['key']=='UserServer'){
	
	if(!isset($_REQUEST['server']) || ($_REQUEST['user'] == '') || ($_REQUEST['userName'] == '') || ($_REQUEST['ticket'] == '') || !isset($_REQUEST['action'])){
		
		$myObj = new stdClass();
		$myObj->host = !isset($_REQUEST['server'])? "Server is required" : "";
		$myObj->user = $_REQUEST['user'] == '' ? "User is required" : "";
		$myObj->userName = $_REQUEST['userName'] == '' ? "User name is required" : "";
		//$myObj->userPassword = $_REQUEST['userPassword'] == '' ? "Password is required" : "";
		//$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->action = !isset($_REQUEST['action']) ? "Action is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$sID = $_REQUEST['server'];
		$user = $_REQUEST['user'];
		$userName = trim($_REQUEST['userName']);
		//$status = $_REQUEST['status'];
		//$pass = rand(111111, 999999);
		//$pass = trim($_REQUEST['userPassword']);
		//$secure_key = substr(md5(time()), 0, 10);
		//include('encrypt.php');
		//$password = encrypt($pass,$secure_key);
		
		
		$myObj = new stdClass();
		
		$sql_user = "SELECT id,email FROM users WHERE email = '$user'";
		 $result_user = $conn->query($sql_user);
		 $myObj->user = mysqli_num_rows($result_user)>=1 ? "" : "This user is not exists";
		 
		if($myObj->user != ''){
		    $myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		 
		 $row_user = mysqli_fetch_assoc($result_user);
		 $uID = $row_user['id'];
		
		/*
		$sql_check_connects = "SELECT * FROM server_users WHERE server_id = $sID AND user_id = $uID";
		 $result_check_connects = $conn->query($sql_check_connects);
		 $myObj->host = mysqli_num_rows($result_check_connects)>=1 ? "This Server is already assigned to selected user" : "";
		*/
		 
		$sql_check_userName = "SELECT user FROM server_users WHERE user = '$userName' AND server_id = $sID";
		 $result_check_userName = $conn->query($sql_check_userName);
		 $myObj->userName = mysqli_num_rows($result_check_userName)>=1 ? "This user name is already exists on selected server" : "";
		 
		$sql_check_user = "SELECT email FROM users WHERE email = '$user'";
		 $result_check_user = $conn->query($sql_check_user);
		 $myObj->user = mysqli_num_rows($result_check_user)>=1 ? "" : "This user is not exists";
		 
		 
		if($myObj->userName != '' || $myObj->user != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
	    $sql = "INSERT INTO server_users (server_id, user_id, user) VALUES($sID, $uID, '$userName')";
		
		$sql_get_user = "SELECT f_name, l_name, email FROM users WHERE id = $uID";
		 $result_get_user = $conn->query($sql_get_user);
		 $row_get_user = mysqli_fetch_assoc($result_get_user);
		 $uName = $row_get_user['f_name']." ".$row_get_user['l_name'];
		 $uEmail = $row_get_user['email'];
		
		if($conn->query($sql) === TRUE) {
			include('mail.php');
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
       $conn->close();
	}
} 


if($_REQUEST['key']=='AddUserServer'){

	if(!isset($_REQUEST['sourceServer']) || !isset($_REQUEST['targetServer']) || ($_REQUEST['sourceUser'] == '') || ($_REQUEST['targetUser'] == '') || ($_REQUEST['ticket'] == '') || !isset($_REQUEST['sourceAccountType'])){
		
		$myObj = new stdClass();
		$myObj->sourceServer = !isset($_REQUEST['sourceServer'])? "Source server is required" : "";
		$myObj->targetServer = !isset($_REQUEST['targetServer'])? "Target server is required" : "";
		$myObj->sourceAccountType = !isset($_REQUEST['sourceAccountType']) ? "Source account type is required" : "";
		$myObj->sourceUser = !isset($_REQUEST['sourceUser']) ? "Source user is required" : "";
		$myObj->targetUser = !isset($_REQUEST['targetUser']) ? "Target user is required" : "";
		$myObj->ticket = $_REQUEST['ticket'] == '' ? "Ticket is required" : "";
		//$myObj->sourceSSHKey = $_REQUEST['sourceSSHKey'] == '' ? "Source SSH key is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$sourceServer = $_REQUEST['sourceServer'];
		$targetServer = $_REQUEST['targetServer'];
		$sourceUser = $_REQUEST['sourceUser'];
		$targetUser = $_REQUEST['targetUser'];
		$sourceAccountType = $_REQUEST['sourceAccountType'];
		//$sourceSSHKey = $_REQUEST['sourceSSHKey'];
		
		$sql_s = "SELECT servers.host_name, server_users.user from servers, server_users WHERE servers.id = server_users.server_id AND server_users.id = $sourceUser AND server_users.server_id = $sourceServer";
			$result_s = mysqli_query($conn , $sql_s);
			$row_s = mysqli_fetch_assoc($result_s);
			$host_s = $row_s['host_name'];
			$user_s = $row_s['user'];
			
		$sql_t = "SELECT servers.host_name, server_users.user from servers, server_users WHERE servers.id = server_users.server_id AND server_users.id = $targetUser AND server_users.server_id = $targetServer";
			$result_t = mysqli_query($conn , $sql_t);
			$row_t = mysqli_fetch_assoc($result_t);
			$host_t = $row_t['host_name'];
			$user_t = $row_t['user'];
		
        $data_encrypt = '{"sourceServer":"'.$host_s.'","sourceUser":"'.$user_s.'","targetServer":"'.$host_t.'","targetUser":"'.$user_t.'"}';
		
		$secure_key = substr(md5(time()), 0, 10);
		include('encrypt.php');
		$encrypted_key = encrypt($data_encrypt,$secure_key);
		
		$myObj = new stdClass();
		
		if($sourceServer == $targetServer){
			$myObj->targetServer = "Target server and Source server could not be same";
		    $myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		/*
		$sql_source_user = "SELECT * FROM servers, server_users WHERE server_users.server_id = servers.id AND servers.id = $sourceServer AND server_users.user = '$sourceUser'";
		 $result_source_user = $conn->query($sql_source_user);
		 $myObj->sourceUser = mysqli_num_rows($result_source_user)>=1 ? "" : "This source user is not exists";
		 
		$sql_target_user = "SELECT * FROM servers, server_users WHERE server_users.server_id = servers.id AND servers.id = $sourceServer AND server_users.user = '$sourceUser'";
		 $result_target_user = $conn->query($sql_target_user);
		 $myObj->targetUser = mysqli_num_rows($result_target_user)>=1 ? "" : "This target user is not exists";
		
		
		if($myObj->sourceUser != ''|| $myObj->targetUser != ''){
			if($myObj->sourceUser != '') $myObj->targetUser = '';
		    $myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		 */
		 
		 /* $row_user = mysqli_fetch_assoc($result_user);
		 $uID = $row_user['id'];
		 
		$sql_check_connects = "SELECT * FROM server_users WHERE server_id = $sID AND user_id = $uID";
		 $result_check_connects = $conn->query($sql_check_connects);
		 $myObj->host = mysqli_num_rows($result_check_connects)>=1 ? "This Server is already assigned to selected user" : "";
		 
		$sql_check_userName = "SELECT user FROM server_users WHERE user = '$userName'";
		 $result_check_userName = $conn->query($sql_check_userName);
		 $myObj->userName = mysqli_num_rows($result_check_userName)>=1 ? "This user name is already exists" : "";
		 
		$sql_check_user = "SELECT email FROM users WHERE email = '$user'";
		 $result_check_user = $conn->query($sql_check_user);
		 $myObj->user = mysqli_num_rows($result_check_user)>=1 ? "" : "This user is not exists";
		 
		 
		if($myObj->host != '' || $myObj->userName != '' || $myObj->user != ''){
			if($myObj->user != '') $myObj->host = '';
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
	    $sql = "INSERT INTO server_users (server_id, user_id, user, password, secure_key) VALUES($sID, $uID, '$userName', '$password', '$secure_key')";
		
		$sql_get_user = "SELECT f_name, l_name, email FROM users WHERE id = $uID";
		 $result_get_user = $conn->query($sql_get_user);
		 $row_get_user = mysqli_fetch_assoc($result_get_user);
		 $uName = $row_get_user['f_name']." ".$row_get_user['l_name'];
		 $uEmail = $row_get_user['email']; */
		 
		
		$sql = "INSERT INTO password_encryption (source_server_id, source_user_id, source_account_type, target_server_id, target_user_id, encrypt_key, secure_key) VALUES($sourceServer, $sourceUser, $sourceAccountType, $targetServer, $targetUser, '$encrypted_key', '$secure_key')"; 
		
		if($conn->query($sql) === TRUE) {
			//$filePath = dirname(__FILE__, 3).'/key.txt';
			//$myFile = fopen($filePath, "a");
			//$myFile = file_get_contents($filePath, $sshKey.PHP_EOL, FILE_APPEND | LOCK_EX);
			//fwrite($myFile, PHP_EOL .$sourceSSHKey);
			//fclose($myFile);
			
			$myObj = new stdClass();
			$myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myObj->ecnrypted_key = trim($encrypted_key);
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myObj->encrypt_key = "";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	}
} 





		function decrypt($message,$encryption_key){
			$key = $encryption_key;
			$message = base64_decode(urldecode($message));
			$nonceSize = openssl_cipher_iv_length('aes-256-ctr');
			$nonce = mb_substr($message, 0, $nonceSize, '8bit');
			$ciphertext = mb_substr($message, $nonceSize, null, '8bit');

			$plaintext= openssl_decrypt(
			  $ciphertext, 
			  'aes-256-ctr', 
			  $key,
			  OPENSSL_RAW_DATA,
			  $nonce
			);
			
		  return $plaintext;
		}
		

?>