    <div id="loaderImg"> 
          <img src="../img/loader.gif">
    </div>
	
	<script src="assets/js/jquery-3.2.1.min.js"></script>
	<!-- Bootstrap Core JS -->
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- Slimscroll JS -->
	<!-- Datatables JS -->
	<script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
	<script src="assets/plugins/datatables/datatables.min.js"></script>
	<script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/plugins/raphael/raphael.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
	<script src="assets/js/script.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
	

    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/js/select2.min.js" defer></script>-->
	
	<?php include("js/custom-js.php"); ?>
	
	<?php
	  $arr = [0];
	?>
	
	<script>
        // Initialize the DataTable
        $(document).ready(function () {
            $('.datatable').DataTable({
				destroy: true,
                searching: true,
			});
			
			$('a.toggle-vis').on('click', function (e) {
				e.preventDefault();
				var column = $('.datatable').DataTable().column($(this).attr('data-column'));
				column.visible(!column.visible());
			});
			
			//$('.datatable').DataTable().columns( <?php echo json_encode($arr); ?> ).visible( false );
        });
    </script>
	

	
 </body>

</html>