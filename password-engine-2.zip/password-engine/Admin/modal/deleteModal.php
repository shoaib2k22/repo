<div id="addFormModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-body text-center">
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Are you sure want to delete <?=$_REQUEST['name'];?> ?</h3>
				<div class="m-t-20"> 
				    <button class="btn btn-danger" onclick='deleteOnDB("<?=$_REQUEST['id'];?>","<?=$_REQUEST['key'];?>")'>Delete</button>
					<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
				</div>
			</div>
		</div>
	</div>
</div>