-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2023 at 12:59 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `accusr`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `market_id` int(11) DEFAULT NULL,
  `f_name` varchar(255) DEFAULT NULL,
  `l_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `email_varified_at` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` int(11) DEFAULT '1',
  `remember_token` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `is_deleted` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `market_id`, `f_name`, `l_name`, `email`, `email_varified_at`, `mobile`, `gender`, `password`, `role`, `remember_token`, `status`, `is_deleted`, `created_at`, `updated_at`) VALUES
(1, 1, 'Admin', NULL, 'admin@vodafone.com', NULL, NULL, NULL, '123', 1, NULL, 1, 0, '2023-03-20 17:34:00', '2023-03-20 17:34:00');

-- --------------------------------------------------------

--
-- Table structure for table `connects`
--

CREATE TABLE `connects` (
  `id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  `market_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `connects`
--

INSERT INTO `connects` (`id`, `role_id`, `server_id`, `market_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, 1, '2023-04-12 10:51:16', '2023-04-12 10:51:16'),
(2, 2, 2, 1, 1, '2023-04-12 11:03:29', '2023-04-12 11:03:29'),
(3, 3, 2, 1, 1, '2023-05-23 06:25:45', '2023-05-23 06:25:45');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `expire_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `user_id`, `file`, `password`, `status`, `expire_at`, `created_at`, `updated_at`) VALUES
(1, 1, '181241-20230427-abc123.pdf', '296523', 1, NULL, '2023-04-27 12:42:41', '2023-04-27 12:42:41'),
(2, 1, '182548-20230427-abc123.pdf', '118977', 1, NULL, '2023-04-27 12:55:48', '2023-04-27 12:55:48'),
(3, 1, '223934-20230427-abc123.pdf', '943935', 1, NULL, '2023-04-27 17:09:34', '2023-04-27 17:09:34'),
(4, 1, '224201-20230427-abc123.pdf', '379504', 1, NULL, '2023-04-27 17:12:01', '2023-04-27 17:12:01'),
(5, 1, '224543-20230427-abc123.pdf', '397165', 1, NULL, '2023-04-27 17:15:43', '2023-04-27 17:15:43'),
(6, 1, '224654-20230427-abc123.pdf', '738467', 1, NULL, '2023-04-27 17:16:54', '2023-04-27 17:16:54'),
(7, 1, '224804-20230427-abc123.pdf', '323114', 1, NULL, '2023-04-27 17:18:04', '2023-04-27 17:18:04'),
(8, 1, '224932-20230427-abc123.pdf', '635573', 1, NULL, '2023-04-27 17:19:32', '2023-04-27 17:19:32'),
(9, 1, '225047-20230427-abc123.pdf', '291036', 1, NULL, '2023-04-27 17:20:47', '2023-04-27 17:20:47'),
(10, 1, '231038-20230427-abc123.pdf', '746631', 1, NULL, '2023-04-27 17:40:38', '2023-04-27 17:40:38'),
(11, 1, '231130-20230427-abc123.pdf', '586994', 1, NULL, '2023-04-27 17:41:30', '2023-04-27 17:41:30'),
(12, 1, '231255-20230427-abc123.pdf', '571960', 1, NULL, '2023-04-27 17:42:55', '2023-04-27 17:42:55'),
(13, 1, '232350-20230427-abc123.pdf', '749858', 1, NULL, '2023-04-27 17:53:50', '2023-04-27 17:53:50'),
(14, 1, '232446-20230427-abc123.pdf', '491966', 1, NULL, '2023-04-27 17:54:46', '2023-04-27 17:54:46'),
(15, 1, '232627-20230427-abc123.pdf', '247851', 1, NULL, '2023-04-27 17:56:27', '2023-04-27 17:56:27'),
(16, 1, '232708-20230427-abc123.pdf', '286521', 1, NULL, '2023-04-27 17:57:08', '2023-04-27 17:57:08'),
(17, 1, '232900-20230427-abc123.pdf', '947010', 1, NULL, '2023-04-27 17:59:00', '2023-04-27 17:59:00'),
(18, 1, '234338-20230427-abc123.pdf', '166295', 1, NULL, '2023-04-27 18:13:38', '2023-04-27 18:13:38'),
(19, 1, '', '', 1, NULL, '2023-04-27 18:26:28', '2023-04-27 18:26:28'),
(20, 1, '', '', 1, NULL, '2023-04-27 18:35:19', '2023-04-27 18:35:19'),
(21, 1, '', '', 1, NULL, '2023-04-27 18:40:09', '2023-04-27 18:40:09'),
(22, 1, '', '', 1, NULL, '2023-04-27 18:42:13', '2023-04-27 18:42:13'),
(23, 1, '', '', 1, NULL, '2023-04-27 18:43:14', '2023-04-27 18:43:14'),
(24, 1, '002150-20230428-abc123.pdf', '675479', 1, NULL, '2023-04-27 18:51:50', '2023-04-27 18:51:50'),
(25, 1, '132806-20230428-abc123.pdf', '962841', 1, NULL, '2023-04-28 07:58:06', '2023-04-28 07:58:06'),
(26, 1, '135320-20230428-abc123.pdf', '357918', 1, NULL, '2023-04-28 08:23:20', '2023-04-28 08:23:20'),
(27, 1, '222432-20230503-abc123.pdf', '121647', 1, NULL, '2023-05-03 16:54:32', '2023-05-03 16:54:32'),
(28, 1, '233657-20230503-abc123.pdf', '770373', 1, NULL, '2023-05-03 18:06:57', '2023-05-03 18:06:57'),
(29, 1, '101508-20230504-abc123.pdf', '797559', 1, NULL, '2023-05-04 04:45:08', '2023-05-04 04:45:08'),
(30, 1, '101616-20230504-abc123.pdf', '344781', 1, NULL, '2023-05-04 04:46:16', '2023-05-04 04:46:16'),
(31, 1, '125407-20230504-abc123.pdf', '715827', 1, NULL, '2023-05-04 07:24:07', '2023-05-04 07:24:07'),
(32, 1, '132725-20230504-abc123.pdf', '900860', 1, NULL, '2023-05-04 07:57:25', '2023-05-04 07:57:25'),
(33, 1, '132751-20230504-abc123.pdf', '722451', 1, NULL, '2023-05-04 07:57:52', '2023-05-04 07:57:52'),
(34, 1, '133141-20230504-abc123.pdf', '726782', 1, NULL, '2023-05-04 08:01:41', '2023-05-04 08:01:41'),
(35, 3, '140225-20230504-pqr123.pdf', '440588', 1, NULL, '2023-05-04 08:32:25', '2023-05-04 08:32:25'),
(36, 3, '140731-20230504-pqr123.pdf', '660598', 1, NULL, '2023-05-04 08:37:31', '2023-05-04 08:37:31'),
(37, 1, '141224-20230504-abc123.pdf', '180806', 1, NULL, '2023-05-04 08:42:24', '2023-05-04 08:42:24'),
(38, 1, '141953-20230504-abc123.pdf', '311971', 1, NULL, '2023-05-04 08:49:53', '2023-05-04 08:49:53'),
(39, 1, '144245-20230504-abc123.pdf', '906298', 1, NULL, '2023-05-04 09:12:45', '2023-05-04 09:12:45'),
(40, 3, '144613-20230504-pqr123.pdf', '424485', 1, NULL, '2023-05-04 09:16:13', '2023-05-04 09:16:13'),
(41, 1, '144901-20230504-abc123.pdf', '308392', 1, NULL, '2023-05-04 09:19:01', '2023-05-04 09:19:01'),
(42, 1, '104548-20230505-abc123.pdf', '756821', 1, NULL, '2023-05-05 05:15:48', '2023-05-05 05:15:48'),
(43, 1, '105034-20230505-abc123.pdf', '806895', 1, NULL, '2023-05-05 05:20:34', '2023-05-05 05:20:34'),
(44, 1, '111343-20230505-abc123.pdf', '135511', 1, NULL, '2023-05-05 05:43:43', '2023-05-05 05:43:43'),
(45, 1, '112135-20230505-abc123.pdf', '659773', 1, NULL, '2023-05-05 05:51:35', '2023-05-05 05:51:35'),
(46, 1, '112642-20230505-abc123.pdf', '815024', 1, NULL, '2023-05-05 05:56:42', '2023-05-05 05:56:42'),
(47, 3, '163627-20230505-pqr123.pdf', '403517', 1, NULL, '2023-05-05 11:06:27', '2023-05-05 11:06:27'),
(48, 1, '175127-20230519-abc123.pdf', '792510', 1, NULL, '2023-05-19 12:21:27', '2023-05-19 12:21:27');

-- --------------------------------------------------------

--
-- Table structure for table `grants`
--

CREATE TABLE `grants` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  `server_user_id` int(11) DEFAULT NULL,
  `market_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `grants`
--

INSERT INTO `grants` (`id`, `user_id`, `role_id`, `server_id`, `server_user_id`, `market_id`, `status`, `created_at`, `updated_at`) VALUES
(11, 1, 1, NULL, NULL, 1, 1, '2023-04-12 10:48:06', '2023-04-12 10:48:06'),
(12, 3, NULL, 3, 5, 1, 0, '2023-04-26 10:51:49', '2023-04-26 10:51:49'),
(13, 3, NULL, 2, 4, 1, 1, '2023-04-26 11:12:31', '2023-05-04 04:58:38'),
(14, 3, NULL, 1, 1, 1, 1, '2023-04-26 11:18:14', '2023-04-26 11:22:02'),
(15, 25, NULL, 2, 4, 1, 0, '2023-04-26 11:39:23', '2023-04-26 11:39:23'),
(16, 25, NULL, 3, 5, 1, 0, '2023-04-28 05:09:16', '2023-04-28 05:09:16'),
(17, 25, NULL, 6, 8, 1, 1, '2023-04-28 05:13:04', '2023-05-04 04:58:24'),
(21, 2, NULL, 2, 4, 1, 1, '2023-04-28 06:21:14', '2023-05-04 04:58:18'),
(25, 2, NULL, 1, 1, 1, 1, '2023-04-28 09:08:48', '2023-05-04 04:58:09'),
(26, 3, NULL, 11, 16, 1, 1, '2023-05-03 12:16:24', '2023-05-04 06:34:01'),
(27, 2, NULL, 11, 16, 1, 1, '2023-05-03 15:22:52', '2023-05-04 06:33:54'),
(28, 2, NULL, 8, 10, 1, 1, '2023-05-03 17:55:51', '2023-05-04 04:57:56'),
(29, 3, NULL, 10, 20, 1, 1, '2023-05-04 08:37:02', '2023-05-04 08:37:13'),
(30, 2, 1, NULL, NULL, 1, 1, '2023-05-23 06:13:13', '2023-05-23 06:13:13');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ticket` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `mails`
--

CREATE TABLE `mails` (
  `id` int(11) NOT NULL,
  `host` varchar(255) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `sender` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mails`
--

INSERT INTO `mails` (`id`, `host`, `port`, `user_name`, `password`, `sender`, `status`, `created_at`, `updated_at`) VALUES
(1, '195.232.244.151', 25, NULL, NULL, 'accrobot08.live008i@vodafone.com', 1, '2023-03-25 07:47:50', '2023-04-05 06:09:58'),
(2, 'smtp.gmail.com', 587, 'sraafey2k14@gmail.com', 'hvpmuodnbtriltvv', 'sraafey2k14@gmail.com', 0, '2023-03-25 07:50:20', '2023-04-05 06:10:07');

-- --------------------------------------------------------

--
-- Table structure for table `markets`
--

CREATE TABLE `markets` (
  `id` int(11) NOT NULL,
  `market` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `markets`
--

INSERT INTO `markets` (`id`, `market`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Germany', 1, '2023-02-01 10:27:54', '2023-04-28 10:02:51'),
(2, 'USA', 1, '2023-02-01 10:27:54', '2023-02-01 10:27:54'),
(3, 'India', 1, '2023-02-08 05:52:28', '2023-04-28 10:05:32'),
(4, 'Ireland', 1, '2023-02-08 05:52:28', '2023-02-08 05:52:28'),
(5, 'Poland', 1, '2023-02-08 05:52:58', '2023-02-08 05:52:58'),
(6, 'Australia', 1, '2023-02-08 05:52:58', '2023-02-16 08:33:58');

-- --------------------------------------------------------

--
-- Table structure for table `password_encryption`
--

CREATE TABLE `password_encryption` (
  `id` int(11) NOT NULL,
  `source_server_id` int(11) DEFAULT NULL,
  `source_user_id` int(11) DEFAULT NULL,
  `source_account_type` int(11) DEFAULT NULL,
  `target_server_id` int(11) DEFAULT NULL,
  `target_user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT '1',
  `encrypt_key` varchar(255) DEFAULT NULL,
  `secure_key` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `password_encryption`
--

INSERT INTO `password_encryption` (`id`, `source_server_id`, `source_user_id`, `source_account_type`, `target_server_id`, `target_user_id`, `created_at`, `updated_at`, `status`, `encrypt_key`, `secure_key`) VALUES
(1, 1, 1, 1, 2, 4, '2023-05-02 09:31:17', '2023-05-02 09:31:17', 1, NULL, NULL),
(2, 1, 1, 1, 2, 4, '2023-05-02 11:14:14', '2023-05-02 11:14:14', 1, NULL, NULL),
(3, 1, 1, 1, 6, 8, '2023-05-02 11:15:22', '2023-05-02 11:15:22', 1, NULL, NULL),
(47, 14, 27, 1, 13, 26, '2023-05-05 10:59:09', '2023-05-05 10:59:09', 1, 'nP3MuYaSBbR%2B1QUMEOj5IPsIbhzKX46tnl5oKNiMXM3gyp9rK8i9oEJagT3FeKx2OEstYWOgeDRlN6T%2B3HT%2B5aQErds7%2FlymE4RlbnhWewOSPaGeruE%2BEXAxWgjCEQsfhpJGEPGyYtwiEACdF%2BR%2BqpM%3D', 'b6ba89a449'),
(48, 13, 28, 1, 11, 19, '2023-05-19 12:08:00', '2023-05-19 12:08:00', 1, 'yAdTtW2eMF9307Ds3hiidEwupTW3e6AHAsYUMMcrgnd28ogdWVIqd4zuJmUcfatfWPOimpjO3lTF09uYb56g%2FgwioMakFJpINK%2B6TeLBGE8M2uqkmnJRXAO1pQgppozXq5IGaz7w9qYCUg5Z4qRM9seBzg%3D%3D', '7b50df193d');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `market_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role`, `department_id`, `market_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Database', NULL, 1, 1, '2023-04-12 10:46:38', '2023-04-12 10:46:38'),
(2, 'Middleware', NULL, 1, 1, '2023-04-12 10:49:41', '2023-04-12 10:49:41'),
(3, 'testing', NULL, 1, 1, '2023-05-23 06:22:57', '2023-05-23 06:22:57');

-- --------------------------------------------------------

--
-- Table structure for table `role_requests`
--

CREATE TABLE `role_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `market_id` int(11) DEFAULT NULL,
  `is_approved` int(11) DEFAULT '0',
  `is_pending` int(11) DEFAULT '1',
  `is_declined` int(11) DEFAULT '0',
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `role_requests`
--

INSERT INTO `role_requests` (`id`, `user_id`, `role_id`, `market_id`, `is_approved`, `is_pending`, `is_declined`, `description`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 1, 0, 1, 0, NULL, '2023-05-03 18:07:28', '2023-05-03 18:07:28');

-- --------------------------------------------------------

--
-- Table structure for table `servers`
--

CREATE TABLE `servers` (
  `id` int(11) NOT NULL,
  `market_id` int(11) DEFAULT NULL,
  `host_name` varchar(255) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `os_type` varchar(255) DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `secure_key` varchar(255) DEFAULT NULL,
  `password_expires_at` timestamp NULL DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `servers`
--

INSERT INTO `servers` (`id`, `market_id`, `host_name`, `port`, `os_type`, `ip_address`, `password`, `secure_key`, `password_expires_at`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'vg6673yw', NULL, 'windows', '192.162.12.72', '2VP%2BiiJ7SYKBzwYVAxj6S1mM7Q%3D%3D', '04f681d6e6', NULL, 1, '2023-03-20 17:51:44', '2023-05-04 19:58:38'),
(2, 1, 'vg6670yw', NULL, 'windows', '192.162.12.70', 'DcFFJoHao3BeL1Z9fXIAXp%2FLSw%3D%3D', '2ec91cbbc7', NULL, 1, '2023-03-20 17:52:47', '2023-05-04 19:59:21'),
(3, 1, 'vg6675yw', NULL, 'windows', '195.233.238.5', '2VP%2BiiJ7SYKBzwYVAxj6S1mM7Q%3D%3D', '04f681d6e6', NULL, 1, '2023-03-20 17:51:44', '2023-05-04 19:59:43'),
(5, 1, 'vg6676yw', NULL, 'windows', '195.233.238.52', '2VP%2BiiJ7SYKBzwYVAxj6S1mM7Q%3D%3D', '04f681d6e6', NULL, 1, '2023-03-20 17:51:44', '2023-05-04 20:00:22'),
(6, 1, 'vg6672yw', NULL, 'windows', '195.233.238.119', 'DcFFJoHao3BeL1Z9fXIAXp%2FLSw%3D%3D', '2ec91cbbc7', NULL, 1, '2023-03-20 17:52:47', '2023-05-04 20:00:36'),
(8, 1, 'vgssh3hr', NULL, NULL, '195.233.238.110', NULL, NULL, NULL, 1, '2023-04-28 09:33:50', '2023-04-28 09:33:50'),
(10, 1, 'votstehr', NULL, NULL, '10.97.102.108', NULL, NULL, NULL, 1, '2023-05-02 08:34:39', '2023-05-02 08:34:39'),
(11, 1, 'vg4044yr', NULL, NULL, '176.125.21.14', NULL, NULL, NULL, 1, '2023-05-03 04:53:46', '2023-05-03 04:53:46'),
(13, 1, 'vgg218yr', NULL, NULL, '139.47.187.171', NULL, NULL, NULL, 1, '2023-05-05 10:47:36', '2023-05-05 10:47:36'),
(14, 1, 'uppsala2', NULL, NULL, '195.233.238.7', NULL, NULL, NULL, 1, '2023-05-05 10:57:52', '2023-05-05 10:57:52');

-- --------------------------------------------------------

--
-- Table structure for table `server_users`
--

CREATE TABLE `server_users` (
  `id` int(11) NOT NULL,
  `server_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user` varchar(22) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `secure_key` varchar(255) DEFAULT NULL,
  `last_password_changed` timestamp NULL DEFAULT NULL,
  `password_rotation_period` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `server_users`
--

INSERT INTO `server_users` (`id`, `server_id`, `user_id`, `user`, `password`, `secure_key`, `last_password_changed`, `password_rotation_period`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'sakhtar', 'NKFIBmjy4mCDt7FmxJnI7tl7dQdUkQ%3D%3D', '200feca0ca', NULL, NULL, 1, '2023-03-20 18:11:33', '2023-05-03 18:08:48'),
(4, 2, 1, 'vshete', 'Ga1QRY7%2FqFsPFQfjifKXBrm2Htt%2Bog%3D%3D', '5e4b515b5c', NULL, NULL, 1, '2023-03-25 13:36:29', '2023-04-26 11:07:15'),
(5, 3, 1, 'vshete', 'NKFIBmjy4mCDt7FmxJnI7tl7dQdUkQ%3D%3D', '200feca0ca', NULL, NULL, 1, '2023-03-20 18:11:33', '2023-04-13 15:18:50'),
(6, 4, 1, 'vshete', 'Ga1QRY7%2FqFsPFQfjifKXBrm2Htt%2Bog%3D%3D', '5e4b515b5c', NULL, NULL, 0, '2023-03-25 13:36:29', '2023-04-13 15:28:36'),
(7, 5, 1, 'techvi01', 'NKFIBmjy4mCDt7FmxJnI7tl7dQdUkQ%3D%3D', '200feca0ca', NULL, NULL, 1, '2023-03-20 18:11:33', '2023-04-13 15:26:59'),
(8, 6, 1, 'acc-techvi02', 'Ga1QRY7%2FqFsPFQfjifKXBrm2Htt%2Bog%3D%3D', '5e4b515b5c', NULL, NULL, 1, '2023-03-25 13:36:29', '2023-04-29 18:33:46'),
(9, 7, 3, 'osm', 'kst%2BFfNCZUElaJn7HGot85qSSmabAQ%3D%3D', '5356b0746b', NULL, NULL, 0, '2023-04-28 09:21:04', '2023-04-28 09:21:04'),
(10, 8, 1, 'sraafey', 'L23Gb%2B4Iy6pW1wYZQkYtGA%3D%3D', '80bf519108', NULL, NULL, 1, '2023-04-28 10:59:00', '2023-05-04 06:04:57'),
(15, 10, 1, 'sraafey123', 'VyIrJs9ebYgY83ZUH3OioYaCHQ%3D%3D', 'f176471e01', NULL, NULL, 1, '2023-05-02 17:49:06', '2023-05-04 06:07:43'),
(19, 11, 1, 'testing1', 'Ar3Wc%2FGBZzgJQzVITFyCMFwSb6BtnrxFSy4%3D', 'b87e3b9973', NULL, NULL, 1, '2023-05-03 06:11:14', '2023-05-03 06:12:54'),
(21, 9, 1, 'testing2', 'xdF3YCUBGnOpbocJ%2BUSWT%2F%2BQMhgbPpi8esc%3D', '0fd4750f17', NULL, NULL, 1, '2023-05-04 08:48:32', '2023-05-04 08:49:26'),
(22, 11, 3, 'accusr', 'uIA7CJor0ju0R0495OvDE9sAIQWyslo%3D', '69df751781', NULL, NULL, 1, '2023-05-04 13:39:12', '2023-05-04 13:40:06'),
(23, 1, 1, 'sraafey', 'MHYc6lNFyU1eYnpkdfTnOpxGIA%3D%3D', 'ff144175fa', '2023-05-18 22:00:00', 90, 0, '2023-05-04 20:06:18', '2023-05-23 05:41:49'),
(24, 12, 3, 'accusr', '62kzYj6nqedquGABT0sbzNHZWBBYHqh%2B', '12cf212973', NULL, NULL, 1, '2023-05-05 05:06:50', '2023-05-05 05:07:34'),
(27, 14, 3, 'vshete', 'wBYyxard3mizJ92VNoe1OrYhn9BLc4aJ', 'b5d78dca19', NULL, NULL, 1, '2023-05-05 10:58:19', '2023-05-05 10:58:42'),
(28, 13, 1, 'accusr', NULL, NULL, NULL, NULL, 0, '2023-05-19 11:55:46', '2023-05-19 11:55:46');

-- --------------------------------------------------------

--
-- Table structure for table `show_hide_columns`
--

CREATE TABLE `show_hide_columns` (
  `id` int(11) NOT NULL,
  `table` varchar(255) DEFAULT NULL,
  `column` varchar(255) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `is_show` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `unix_id` varchar(255) DEFAULT NULL,
  `market_id` int(11) DEFAULT NULL,
  `f_name` varchar(255) DEFAULT NULL,
  `l_name` varchar(255) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `email_varified_at` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `role` int(11) DEFAULT '0' COMMENT '0:- Personal user\r\n1:- Standard user',
  `password` varchar(255) DEFAULT NULL,
  `password_expires_at` timestamp NULL DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `is_active` int(11) NOT NULL DEFAULT '1',
  `is_deleted` int(11) DEFAULT '0',
  `remember_token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `unix_id`, `market_id`, `f_name`, `l_name`, `gender`, `email`, `email_varified_at`, `mobile`, `role`, `password`, `password_expires_at`, `status`, `is_active`, `is_deleted`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'abc123', 1, 'Shoaib', 'Akhtar', NULL, 'shoaib.akhtar@vodafone.com', NULL, NULL, 0, '$2y$10$RxSba5FP3AfzfWuKJY3oTeUgGiVT2nyYgylP23UqVaDgKdP9cWZXC', NULL, 1, 1, 0, NULL, '2023-03-20 17:37:29', '2023-05-05 10:11:06'),
(2, 'xyz123', 1, 'Sushil', 'Gurjar', NULL, 'sushil.gurjar@vodafone.com', NULL, NULL, 0, '$2y$10$RxSba5FP3AfzfWuKJY3oTeUgGiVT2nyYgylP23UqVaDgKdP9cWZXC', NULL, 1, 1, 0, NULL, '2023-03-20 17:39:38', '2023-05-02 05:12:27'),
(3, 'pqr123', 1, 'Vishal', 'Shete', NULL, 'vishal.shete@vodafone.com', NULL, NULL, 0, '$2y$10$RxSba5FP3AfzfWuKJY3oTeUgGiVT2nyYgylP23UqVaDgKdP9cWZXC', NULL, 1, 1, 0, NULL, '2023-03-20 17:40:47', '2023-05-02 05:12:38'),
(25, '133', 1, 'Komal', 'Naikwadi', NULL, 'komal.naikwadi@vodafone.com', NULL, NULL, 0, '$2y$10$RxSba5FP3AfzfWuKJY3oTeUgGiVT2nyYgylP23UqVaDgKdP9cWZXC', NULL, 1, 1, 0, NULL, '2023-03-25 09:28:44', '2023-05-02 05:12:47'),
(26, '123456', 1, 'Krupakaran', 'V', NULL, 'krupakaran.v@vodafone.com', NULL, NULL, 0, '$2y$10$AHhyIOHch8KhG8zZAtjZAecVtAuqIytg6DC2V8VrEmxvas8Ka02di', NULL, 1, 1, 0, NULL, '2023-05-05 10:01:04', '2023-05-05 10:19:22'),
(27, '123456', 1, 'Purnima', 'Sharma', NULL, 'purnima.sharma02@vodafone.com', NULL, NULL, 0, '$2y$10$JnQJ5Q0rUBB27v2DmpEK8uQnAz.PMHt4NKjNHnY15jcpNg1LDqh.i', NULL, 1, 1, 0, NULL, '2023-05-05 10:09:32', '2023-05-05 10:19:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `connects`
--
ALTER TABLE `connects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grants`
--
ALTER TABLE `grants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mails`
--
ALTER TABLE `mails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `markets`
--
ALTER TABLE `markets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_encryption`
--
ALTER TABLE `password_encryption`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_requests`
--
ALTER TABLE `role_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `servers`
--
ALTER TABLE `servers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `server_users`
--
ALTER TABLE `server_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `show_hide_columns`
--
ALTER TABLE `show_hide_columns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `connects`
--
ALTER TABLE `connects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `grants`
--
ALTER TABLE `grants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mails`
--
ALTER TABLE `mails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `markets`
--
ALTER TABLE `markets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `password_encryption`
--
ALTER TABLE `password_encryption`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `role_requests`
--
ALTER TABLE `role_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `servers`
--
ALTER TABLE `servers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `server_users`
--
ALTER TABLE `server_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `show_hide_columns`
--
ALTER TABLE `show_hide_columns`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
