<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
          
		  <ul id="sidebarnav">
            <!--
			<li class="user-pro"> 
			    <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false">
			       <img src="http://localhost:81/wyiapp-backend/public/images/icons/user.png" alt="Admin" class="img-circle">
				   <span class="hide-menu">Admin</span>
			    </a>
				<ul aria-expanded="false" class="collapse">
				
					<li class="<?php if(PAGE == 'profile') { echo 'active'; } ?> ">
					   <a class="waves-effect waves-dark <?php if(PAGE == 'profile') { echo 'active'; } ?> " href="profile.php">
					    <i class="fa fa-user"></i> 
						<span class="hide-menu">Profile</span>
					   </a>
					</li>
					
					<li class="<?php if(PAGE == 'changepass') { echo 'changepass'; } ?> ">
					  <a class="waves-effect waves-dark <?php if(PAGE == 'changepass') { echo 'active'; } ?> " href="changepass.php">
					    <i class="fal fa-cog"></i>
					    <span class="hide-menu">Settings</span>
					  </a>
					</li>
					<li>
					  <a data-type="logout" href="../logout.php" class="logout cursor-pointer">
					   <i class="fas fa-sign-out-alt"></i>
					   Logout
					  </a>
					</li>
				</ul>
             </li>
			 -->
				
			 <li class="<?php if(PAGE == 'dashboard') { echo 'active'; } ?> "> 
			   <a class="waves-effect waves-dark <?php if(PAGE == 'dashboard') { echo 'active'; } ?> " href="dashboard.php">
			    <i class="fas fa-tachometer-alt"></i>
			    <span class="hide-menu">Dashboard</span>
			   </a>
			 </li>
			 
			 <li class="user-pro"> 
			    <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false">
			       <i class="fa fa-list"></i> 
				   <span class="hide-menu">Role</span>
			    </a>
				<ul aria-expanded="false" class="collapse">
				
					<li class="<?php if(PAGE == 'role') { echo 'active'; } ?> "> 
					   <a class="waves-effect waves-dark <?php if(PAGE == 'role') { echo 'active'; } ?> " href="role-assigned.php">
						<i class="fa fa-bookmark"></i>
						<span class="hide-menu">Assigned Role</span>
					   </a>
					</li>
					
					<li class="<?php if(PAGE == 'requested') { echo 'active'; } ?> "> 
					   <a class="waves-effect waves-dark <?php if(PAGE == 'requested') { echo 'active'; } ?> " href="role-requested.php">
						<i class="fa fa-shield"></i>
						<span class="hide-menu">Requested Role</span>
					   </a>
					</li>
					
				</ul>
             </li>
			 
			 <li class="<?php if(PAGE == 'user-ownership') { echo 'active'; } ?> ">
			   <a class="waves-effect waves-dark <?php if(PAGE == 'user-ownership') { echo 'active'; } ?> " href="user-ownership.php">
				<i class="fa fa-user-plus"></i>
				<span class="hide-menu">User Ownership</span>
			   </a>
			 </li>
			 
			 <li class="<?php if(PAGE == 'user-approval') { echo 'active'; } ?> ">
			   <a class="waves-effect waves-dark <?php if(PAGE == 'user-approval') { echo 'active'; } ?> " href="user-approval.php">
				<i class="fa fa-cubes"></i>
				<span class="hide-menu">My Approvals</span>
			   </a>
			 </li>
			 
			 <li class="<?php if(PAGE == 'getPassword') { echo 'active'; } ?> "> 
			   <a class="waves-effect waves-dark <?php if(PAGE == 'getPassword') { echo 'active'; } ?> " href="get-password.php">
			    <i class="fa fa-key"></i>
			    <span class="hide-menu">Get Password</span>
			   </a>
			 </li>
			 
			 <div style="margin-top:9vh"></div>
			 
			 <li class="<?php if(PAGE == 'profile') { echo 'active'; } ?> ">
			   <a class="waves-effect waves-dark <?php if(PAGE == 'profile') { echo 'active'; } ?> " href="profile.php">
				<i class="fa fa-user"></i>
				<span class="hide-menu">My Profile</span>
			   </a>
			 </li>
			 
			 <li> 
			   <a class="waves-effect waves-dark" href="../logout.php?key=1">
			    <i class="fas fa-sign-out-alt"></i>
			    <span class="hide-menu">Logout</span>
			   </a>
			 </li>
			 
		   </ul>
        </nav>
     </div>
  </aside>