        <div id="loaderImg"> 
          <img src="images/sLoader.gif">
       </div>
	  
	  
	  </div>
     </div>
    </div>

	<script src="public/js/common/jquery.js"></script>
	<script src="public/js/common/popper.min.js"></script>
	<script src="public/js/common/bootstrap.min.js"></script>
	<script src="public/js/common/perfect-scrollbar.jquery.min.js"></script>
	<script src="public/js/common/waves.js"></script>
	<script src="public/js/common/sidebarmenu.js"></script>
	<script src="public/js/common/custom.min.js"></script>
	<script src="public/js/common/jquery.dataTables.min.js"></script>
	<script src="public/js/common/dataTables.buttons.min.js"></script>
	<!--<script src="public/js/common/sweetalert2.min.js"></script>-->
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

	<script>
	   $(function () {
			var table = $('.data-table').DataTable({
				processing: true,
				//serverSide: true,
			});
	   });
	</script>
	

<?php
 if(PAGE == 'role'){?>
 
	<script>
	    $('#sendRRModal').hide();
		
		function getDetails(role,market) {
			 //alert(role + market);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/getPasswordRequestModal.php',
				 type:'POST',
				 data:{
					   role:role,
					   market:market,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#getPasswordRequestModal').html(result);
					 $('#myModal').modal('show');
				 }
			 });
		 }
		 
		 
		function viweServer(id,role,market) {
			 //alert(id + role + market);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/viewServerModal.php',
				 type:'POST',
				 data:{
					   id:id,
					   role:role,
					   market:market,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#getPasswordRequestModal').html(result);
					 $('#viewServerModal').modal('show');
				 }
			 });
		 }
		 
		 function getRoleRequestModal(id) {
			 //alert(id);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/getRoleRequestModal.php',
				 type:'POST',
				 data:{
					   id:id,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#getPasswordRequestModal').html(result);
					 $('#getRoleRequestModal').modal('show');
				 }
			 });
		 }
		 
		 function sendRoleRequestModal() {
			 //alert(id);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/sendroleRequestModal.php',
				 type:'POST',
				 data:$('#roleRequestForm').serialize(),
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#alertMsg').html(result);
					 $('#getRoleRequestModal').modal('hide');
					 $('#successMsgModal').modal('show');
				 }
			 });
		 }
		 
		 function getSendRRButton(){
			 $('#sendRRModal').show();
		 }
		 
		 function reload(){
			 location.reload();
		  }
		 
	 </script>
	 
<?php } ?>





<?php
 if(PAGE == 'requested'){?>
   
   <script>
        $('#sendRRModal').hide();
		
		function getDetails(role,market) {
			 //alert(role + market);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/getPasswordRequestModal.php',
				 type:'POST',
				 data:{
					   role:role,
					   market:market,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#getPasswordRequestModal').html(result);
					 $('#myModal').modal('show');
				 }
			 });
		 }
		 
		 
		function viweServer(id,role,market) {
			 //alert(id + role + market);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/viewServerModal.php',
				 type:'POST',
				 data:{
					   id:id,
					   role:role,
					   market:market,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#getPasswordRequestModal').html(result);
					 $('#viewServerModal').modal('show');
				 }
			 });
		 }
		 
		 function getRoleRequestModal(id) {
			 //alert(id);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/getRoleRequestModal.php',
				 type:'POST',
				 data:{
					   id:id,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#getPasswordRequestModal').html(result);
					 $('#getRoleRequestModal').modal('show');
				 }
			 });
		 }
		 
		 function sendRoleRequestModal() {
			 //alert(id);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/sendroleRequestModal.php',
				 type:'POST',
				 data:$('#roleRequestForm').serialize(),
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#alertMsg').html(result);
					 $('#getRoleRequestModal').modal('hide');
					 $('#successMsgModal').modal('show');
				 }
			 });
		 }
		 
		 function getSendRRButton(){
			 $('#sendRRModal').show();
		 }
		 
		 function reload(){
			 location.reload();
		  }
	</script>
 
<?php } ?>




<?php
 if(PAGE == 'getPassword'){?>
   
   <script>
       function openModal() {
			 $('#requestModal').modal('show');
			 $('#myModal').modal('hide');
			
		 }
		 


		 function getServerUser(server) {
			 //alert(server);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/getServerUserModal.php',
				 type:'POST',
				 data:{
					   server:server,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#GetServerUser').html(result);
				}
			 });
		 }
		 
		 
		 function getServerUserOnServer(server) {
			 //alert(server);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/getServerUserModal.php',
				 type:'POST',
				 data:{
					   server:server,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#GetServerUserOnServer').html(result);
				 }
			 });
		 }
		 
		 
		 function getServer(role) {
			 //alert(role);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/getServerModal.php',
				 type:'POST',
				 data:{
					   role:role,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#GetServer').html(result);
				 }
			 });
		 }
		 
		 function getReqButton(server) {
			 //alert(server);
			 $("#sendReqButton").show();
		 }
		 
		 
		 function sendFile(key) {
			 //alert(key);
			 
			 if(key == 'server'){ 
			     var data = $('#addFormServerData').serialize()+'&key=server';
			 }
			 if(key == 'role'){
				 var data = $('#addFormData').serialize()+'&key=role';
			 }
			 
			 $('#loaderImg').show();
			 $.ajax({
				 url:'controller/sendMail.php',
				 //url:'http://139.47.169.69/password-engine/User/controller/sendMail.php',
				 type:'POST',
				 data: data,
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#getStatusModal').html(result);
					 $('#requestModal').modal('hide');
					 $("#sendReqButton").hide();
					 $("#GetRole").hide();
					 $("#GetServer").hide();
					 $('#successMsgModal').modal('show');
				}
			 });
		   }
		   
		   
		 function reload(){
			 $('#requestModal').modal('hide');
			 $("#sendReqButton").hide();
			 $("#GetRole").hide();
			 $("#GetServer").hide();
			 $('#successMsgModal').modal('hide');
			 location.reload();
		  }
		  
		 $(document).ready(function(){
			//$('#productTable').DataTable();
			$("#sendReqButton").hide();

		 });
		 
		 
		function copy() {
            var copyText = document.getElementById("copyPassword");

            copyText.select();
			copyText.setSelectionRange(0, 99999); // For mobile devices
            navigator.clipboard.writeText(copyText.value);
  
          }
		  
	</script>

<?php } ?>



<?php
 if(PAGE == 'profile'){?>
 
    <script>
		  var view = document.getElementById("profile_view");
		  var edit = document.getElementById("profile_edit");
		  view.style.display = "none";
		  edit.style.display = "none";
		  
		function show() {
		  edit.style.display = "none";
		  view.style.display = "block";
		}
		
		function hide() {
		  edit.style.display = "none";
		  view.style.display = "none";
		}
		
		function edits() {
		  view.style.display = "none";
		  edit.style.display = "block";
		}
   </script>

 <?php } ?>
 
 
 <script>
 
    function getApproveDetails(key, id, table) {
			 //alert(id);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/getApproveDetailsModal.php',
				 type:'POST',
				 data:{
					   id:id,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#getModal').html(result);
					 $('#addFormModal').modal('show');
				 }
			 });
		}
		
		

    function validate(){
	 $('.form-control-error').empty();
	 
	 let ticket = $('input[name = ticket]').val();
	 let serverName = $('#server').find(":selected").val();
	 let userName = $('input[name = userName]').val();
	 let userValue = $('input[name = userPassword]').val();
	 let changedPasswordDate = $('input[name = changedPasswordDate]').val();
	 let passwordRotationPeriod = $('#passwordRotationPeriod').find(":selected").val();
	 
	 if(ticket == '' || serverName == '' || userName == '' || userValue == '' || passwordRotationPeriod == '' || changedPasswordDate == ''){
		 let ErrorTicket = ticket =='' ? "Ticket No. is required" : "";
		 let ErrorServer = serverName =='' ? "Server is required" : "";
		 let ErrorUserName = userName =='' ? "User name is required" : "";
		 let ErrorPassword = userValue =='' ? "User password is required" : "";
		 let ErrorPasswordChangedDate = changedPasswordDate =='' ? "Date is required" : "";
		 let ErrorpasswordRotationPeriod = passwordRotationPeriod =='' ? "Password rotation period is required" : "";
		 
		    $('#ErrorTicket').html(ErrorTicket);
		    $('#ErrorServer').html(ErrorServer);
		    $('#ErrorUserName').html(ErrorUserName);
			$('#ErrorPassword').html(ErrorPassword);
			$('#ErrorPasswordChangedDate').html(ErrorPasswordChangedDate);
			$('#ErrorpasswordRotationPeriod').html(ErrorpasswordRotationPeriod);
		 return;
	 }
     
	 $('#loaderImg').show();
	 $.ajax({
		 url:'../validate.php',
		 type:'POST',
		 data:{
			   serverName:serverName,
			   userName:userName,
			   userValue:userValue,
			 },
		 success:function(result){
			$('#loaderImg').hide();
			var response = JSON.parse(result);
			
			if (response.code == 200) {
				$('#saveServerUser').removeAttr("disabled");
				$('#validationMessage').html(response.msg);
				$('#validationMessage').attr({style:"color: #008000 !important; display: block"});
			} else {
				$('#saveServerUser').attr('disabled', true);
				$('#validationMessage').html(response.msg);
				$('#validationMessage').attr({style: "color: #e84646 !important; display: block"});
			}
			
		 }
	  });	 
    }

	 
    function updateStatus(status, id, table){
		
		   var pass = "";
		   var date = "";
		   var period = "";
			   
		   if(status == 'Approve' && table == 'Su'){
			   let form = $('#addFormData').serializeArray();
			   
			   var pass = form[2].value;
			   var date = form[3].value;
			   var period = form[4].value;
		   }
		   
           var selectedValue = status;
     		   
		   Swal.fire({
			title: '',
			text: 'Are you sure?',
			icon: 'info',
			showCancelButton: true,
			closeOnConfirm: false,
			animation: "slide-from-left",
			cancelButtonColor: '#d33',
			confirmButtonColor: '#3085d6',
			confirmButtonText: 'Yes, ' +selectedValue+ ' it!',
			showLoaderOnConfirm: true,
			}).then((result) => {
			  if(result.isConfirmed){
			     //alert(result.value);
				 $('#loaderImg').show();
				 $.ajax({
				 url:'controller/update.php',
				 type:'POST',
				 data:{
					   id: id,
					   value: selectedValue,
					   table: table,
					   key: 'updateRequestRole',
					   pass: pass,
					   date: date,
					   period: period
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 var response = JSON.parse(result);
					 //$('#getStatusModal').html(response.msg);
					 //$('#addFormModal').modal('hide');
					 //$('#successMsgModal').modal('show');
					 Swal.fire({
							text: response.text,
							icon: response.msg,
							showCancelButton: true,
							showConfirmButton: false,
							cancelButtonColor: '#d33',
							cancelButtonText: 'Close'
						}).then((result) => {
							location.reload();
					});
				 }
			   });
			 }
		  });
	   }
	   
	   
	function getType(val){
		if(val == 'role'){
			$('#roleBased').show();
			$('#serverBased').hide();
		}
		else{
			$('#roleBased').hide();
			$('#serverBased').show();
		}
	}
	
	function getUser(user, server) {
	// alert(user+server);
	 $('#loaderImg').show();
	 $.ajax({
		 url:'modal/userModal.php',
		 type:'POST',
		 data:{
			   user:user,
			   server:server,
			 },
		 success:function(result){
			 $('#loaderImg').hide();
			 $('#getModal').html(result);
			 $('#getUserPerServer').modal('show');
		 }
	 });
   }
   
 
 </script>
 
 
	

 </body>
</html>