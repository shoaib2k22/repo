<?php
header('Access-Control-Allow-Origin: *');
echo get_current_user();
echo "<br/>";
echo $_SERVER['REMOTE_ADDR'];
echo "<br/>";
echo gethostname;
echo "<br/>";
echo php_uname(n);
?>