<?php

define('TITLE', 'Dashboard');
define('PAGE', 'dashboard');

include('controller/include.php');

?>


<style>
 
 .text-white {
    color: #fff !important;
    font-size: 25px;
    border-radius: 5px;
    padding: 6px;
}
 
 .card {
	 background: #fff;
     border-width: 0;
     border-radius: .25rem;
     box-shadow: 0 1px 3px rgba(0, 0, 0, .05);
     margin-bottom: 1.5rem
	 
     position: relative;
     display: flex;
     flex-direction: column;
     min-width: 0;
     word-wrap: break-word;
     background-color: #fff;
     background-clip: border-box;
     border: 1px solid rgba(19, 24, 44, .125);
     border-radius: .25rem
 }

 .card-header {
     padding: .75rem 1.25rem;
     margin-bottom: 0;
     background-color: rgba(19, 24, 44, .03);
     border-bottom: 1px solid rgba(19, 24, 44, .125)
 }

 .card-header:first-child {
     border-radius: calc(.25rem - 1px) calc(.25rem - 1px) 0 0
 }

 card-footer, .card-header {
     background-color: transparent;
     border-color: rgba(160, 175, 185, .15);
     background-clip: padding-box
 }
 

    
</style>


    
  
<div class="col-sm-12 col-md-12">
  <div class="col-12 mt-5">
	  <h3>Hello <?php echo $uFName." ".$grettings;?></h3>
	  <p>Welcome to _VOIS</p>
  </div>
 
 <style>
 p{
	margin:0;
 }
 .card-text{
	 font-size:18px;
 }
 .card-body {
    flex: 1 1 auto;
    padding: 1rem;
}
.text-white {
    color: #fff !important;
    font-size: 25px;
    border-radius: 3px;
    padding: 6px;
}
 
 </style>

  <div class="row gx-5 mt-4">
		<div class="col-xxl-3 col-md-4 mb-5 pd">
			<div class="card card-raised border-start border-success border-4">
				<div class="card-body px-4">
					<div class="me-2">
						<div class="icon-circle bg-success text-white">
						   <i class="fa fa-industry"></i>
						   <span class="card-text"> &nbsp Role Request</span>
						</div>
					</div>
					<div class="d-flex justify-content-between align-items-center mt-2">
					   <p><a class="btn text-success" href="<?php echo $card_1_link; ?>">1 Assigned</a></p>
					   <p><a class="btn text-warning" href="<?php echo $card_1_link; ?>">2 Pending</a></p>
					   <p><a class="btn text-danger" href="<?php echo $card_1_link; ?>">4 Declined</a></p>
					</div>
				</div>
			</div>
		</div>
		
		<div class="col-xxl-3 col-md-4 mb-5 pd">
			<div class="card card-raised border-start border-warning border-4">
				<div class="card-body px-4">
					<div class="d-flex justify-content-between align-items-center mb-2">
						<div class="me-2">
							<div class="display-5" id="users"><?php echo $card_2_count; ?></div>
							<div class="card-text"><?php echo $card_2_text; ?></div>
						</div>
						<div class="icon-circle bg-warning text-white">
						   <i class="fa fa-paper-plane"></i>
						   <a class="btn" href="<?php echo $card_2_link; ?>">View</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="col-xxl-3 col-md-4 mb-5 pd">
			<div class="card card-raised border-start border-primary border-4">
				<div class="card-body px-4">
					<div class="d-flex justify-content-between align-items-center mb-2">
						<div class="me-2">
							<div class="display-5" id="users"><?php echo $card_3_count; ?></div>
							<div class="card-text"><?php echo $card_3_text; ?></div>
						</div>
						<div class="icon-circle bg-primary text-white">
						   <i class="fa fa-map"></i>
						   <a class="btn" href="<?php echo $card_3_link; ?>">View</a>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>
	



<?php include('layout/footer.php'); ?>