<?php
define('TITLE', 'User Approval');
define('PAGE', 'userApproval');

include('controller/include.php');
 
?>


<div class="row">
   <div class="col-12">
	  <div class="card">
	     <div class="card-body">
			<div class="table-responsive">
				<table class="table align-items-center table-flush data-table" id="dbtable">
					<thead>
						<tr>
							<th>#</th>
							<th>Server</th>
							<th>User</th>
							<th>Created On</th>
							<th>Updated On</th>
							<th class="text-right pr-5">Actions</th>
						</tr>
					</thead>
					<tbody>
					 <?php
					   foreach( $result as $key=>$row ){ ?>
						<tr>
							<td><?=++$key?></td>
							
							<td><?=$row["host_name"]?></td>
							
							<td><?=$row["user"]?></td>
							
							<td><?=date('d-M-Y', strtotime($row["created_at"]))?></td>
							
							<td><?=date('d-M-Y', strtotime($row["updated_at"]))?></td>
							
							<?php
								if($row['status']==0){ $status = 'Pending'; $btnColor = 'btn-warning'; $icon = 'fa fa-clock';}
								if($row['status']==1){ $status = 'Approved'; $btnColor = 'btn-success'; $icon = 'fa fa-check';}
								if($row['status']==2){ $status = 'Declined'; $btnColor = 'btn-danger'; $icon = 'fa fa-ban';}
							?>
							
							<td class="text-right">
							  <div class="btn-group open">
								  <a class="btn <?=$btnColor?>" href="#"><i class="<?=$icon?> fa-fw"></i> <?=$status?>
								  </a>
								  <a class="btn <?=$btnColor?>" data-toggle="dropdown" href="#">
									<span class="fa fa-caret-down" title="Toggle dropdown menu"></span>
								  </a>
								  
								  <div class="dropdown-menu dropdown-menu-right">
									  
									  <button class="dropdown-item" onclick="updateStatus('Pending', <?=$row['id']?>, 'Su')" <?php if($row['status']==0){ echo "disabled"; } ?>>
										<i class="fa fa-clock m-r-5 text-warning"></i>Pending
									  </button>
									  
									  <!--
									  <button class="dropdown-item" onclick="updateStatus('Approve', <?=$row['id']?>, 'Su')" <?php if($row['status']==1){ echo "disabled selected"; } ?>>
									   <i class="fa fa-check-square m-r-5 text-success"></i>Approve
									  </button>
									  -->
									  
									  <button class="dropdown-item" onclick="getApproveDetails('Approve', <?=$row['id']?>, 'Su')" <?php if($row['status']==1){ echo "disabled selected"; } ?>>
									   <i class="fa fa-check-square m-r-5 text-success"></i>Approve
									  </button>
									  
									  <button class="dropdown-item" onclick="updateStatus('Decline', <?=$row['id']?>, 'Su')" <?php if($row['status']==2){ echo "disabled selected"; } ?>>
										<i class="fa fa-ban m-r-5 text-danger"></i>Decline
									  </button>
									  
									</div>
								 </td>
							 </tr>
						   <?php } ?>
					</tbody>
				</table>
			</div>
		 </div>
	   </div>
    </div>
  </div>
</div>

<div id="getModal"></div>
   
	
<?php 
  include('layout/footer.php'); 
  $conn->close();
?>