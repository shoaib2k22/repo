<?php
$role_id=$_POST['id'];
$role=$_POST['role'];
$market_id=$_POST['market'];

include('../../dbConnection.php');

  $cSql = "SELECT DISTINCT server_users.user, servers.host_name from connects,servers,server_users WHERE connects.role_id = $role_id AND connects.server_id = servers.id AND servers.market_id = $market_id AND server_users.server_id = servers.id";
	$cResult = mysqli_query($conn, $cSql);

?>

<style>
.card{
	box-shadow: inset 0 -3em 3em rgba(0, 0, 0, 0.1), 0 0 0 2px rgb(255, 255, 255),
    0.3em 0.3em 1em rgba(0, 0, 0, 0.3);
}
</style>

<style>
#viewServerModal table {
  border-collapse: collapse;
  width: 100%;
}

#viewServerModal th, #viewServerModal td {
  text-align: left;
  padding: 8px;
}

#viewServerModal tr:nth-child(even) {background-color: #f2f2f2;}

#viewServerModal .table .thead-light th {
    color: #ffffff;
    background-color: #d12738;
    border-color: #78797a;
}

#viewServerModal .table th, #viewServerModal .table td {
    padding: 0.5rem;
    vertical-align: top;
    border-top: 1px solid #dee2e6;
}
</style>

<div class="modal fade delete-modal" id="viewServerModal">
	<div class="modal-dialog modal-dialog-centered modal-lg">
	<div class="modal-content">

	  <!-- Modal Header -->
	  <div class="modal-header">
		<h4 class="modal-title"><?=$role;?></h4>
		<button type="button" class="close" data-dismiss="modal">&times;</button>
	  </div>

	<!-- Modal body -->
		
			<div class="modal-body">
			   <div class="table-responsive">
				  <table class="table align-items-center table-flush data-table" id="dbtable">
					  <thead class="thead-light text-center">
					   <tr>
						  <th scope="col">#</th>
						  <th scope="col">Role</th>
						  <th scope="col">Server</th>
						  <th scope="col" data-orderable="false">User</th>
						</tr>
					 </thead>
					  
					 <tbody class="text-center">
					  <?php $count = 0;
						while($cRow = $cResult->fetch_assoc()){ ?>
						<tr role="row">
							<td scope="row"><?= ++$count;?></td>
							<td><?=$role; ?></td>
							<td><?=$cRow['host_name']; ?></td>
							<td><?=$cRow['user']; ?></td>
						</tr>
					   <?php } ?>
					 </tbody> 
				  </table>
				</div>
			 </div>
			
	<!-- Modal body end-->	  
		
      <!-- Modal Footer -->		
	  <div class="modal-footer float-right">
		  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	  </div>
	  <!-- Modal Footer end-->	
		
	 </div>
   </div>
</div>