<?php
require('../../phpmailer/PHPMailerAutoload.php');

$sql_mail = "SELECT * FROM mails WHERE status = 1";
 $result_mail = $conn->query($sql_mail);
 $row_mail = mysqli_fetch_assoc($result_mail);
 $mailHost = $row_mail['host'];
 $mailPort = $row_mail['port'];
 $mailUser = $row_mail['user_name'];
 $mailPassword = $row_mail['password'];
 $mailSender = $row_mail['sender'];
	  

if($_REQUEST['key']=='ServerGrant'){
	
	$htmlbody_owner = '
			 <html lang="en">
				 <head>
				   <title>Password-Engine</title>
				</head>
                <body style="margin:0; padding:0; background:#f4f4f4">
				  <div class="content" id="wrapper">
					<div class="nw_layout_LAYOUT1">
					  <table align="center" border="0" cellpadding="0" cellspacing="0" class="CoverPage" id="CoverPage" style="" width="600">
						<tr>
						  <td id="header" valign="top" width="600" style="width: 100%;
							padding: 0px 0px 8px 0px;">
							<table id="nw_masthead_wrapper" class="nw_component_wrapper" cellpadding="0" cellspacing="0">
							   <tr>
								<td class="nw-componentSpacerMainCell">
									<table cellpadding="0" cellspacing="0" class="ContentBlock" id="masthead" style="margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;" width="100%">
									  <tr>
										<td class="nw-componentMainCell">
										   <img alt="" src="vois.jpg" width="600" height="301" /></a>
										</td>
									  </tr>
									</table>
								</td>
							  </tr>
							</table>
						  </td> 
						</tr>
						
						<tr>
						  <td id="main" valign="top" width="600" style="width: 100%; padding-left: 0px; padding-right: 0px; background-color: #ffffff;">
							<table id="nw_maintitle_wrapper" class="nw_component_wrapper" cellpadding="0" cellspacing="0" width="100%">
							  <tr>
								<td class="nw-componentSpacerMainCell">
								   <table cellpadding="0" cellspacing="0" class="ContentBlock" id="maintitle" style="margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;" width="100%">
									  <tr>
										 <td class="nw-componentMainCell">
											<table style="width: 100%;" border="0" cellpadding="0" cellspacing="0">
											   <tbody>
												 <tr>
													<td class="main_title" style="font-family: sans-serif; font-size: 16px; color: #FFFFFF; font-weight:300; font-style: normal; text-decoration: none; background-color: #000000; padding: 8px; border: 1px solid #FFFFFF;">Password Engine<br/></td>
												 </tr>
												</tbody>
											</table>
										  </td>
									  </tr>
									</table>
								</td>
							  </tr>
							</table>

							<table id="nw_maincontent_wrapper" class="nw_component_wrapper" cellpadding="0" cellspacing="0" width="100%">
								<tr>
								  <td class="nw-componentSpacerMainCell">
									 <table cellpadding="0" cellspacing="0" class="ContentBlock" id="maincontent" style="margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;" width="100%">
										<tr>
										  <td class="nw-componentMainCell">
											 <table style="width: 100%;" border="0" cellpadding="0" cellspacing="0">
												<tbody>
												   <tr>
													  <td class="main_content" style="font-size: 16px; color: #000000; font-weight: normal; font-style: normal; text-decoration: none; padding: 10px;">
														<p style="margin: 1.3rem 0rem; margin-top:12px; font-size: 9pt; font-family: Calibri, sans-serif;">
														  <span style="font-family: sans-serif; color: black;">Hello '.$name_user_owner.'</span>
														</p>
														
														<p style="margin: 1.3rem 0rem; font-size: 9pt; font-family: Calibri, sans-serif;">
															<span style="font-family: sans-serif; color: black;">User '.$requesterEmail.' has requested to get access for unix account '.$userName.' on server '.$serverName.'</span>
														</p>
														
														<p style="margin: 1.3rem 0rem; font-size: 9pt; font-family: Calibri, sans-serif;">
															<span style="font-family: sans-serif; color: black;">
															  In order to approve/reject , please logon to <a href="http://139.47.169.69/password-engine/">www.password-engine-vodafone.com.</a>
															</span>
														</p>
														
														<p style="margin: 1.3rem 0rem; font-size: 9pt; font-family: Calibri, sans-serif;">
															<span style="font-family: sans-serif; color: black;">For any issue, please reach out to<a href="#" style="color: #000000c7">pe@vodafone.com.</a>
															</span>
														</p>
														
														<p style="margin-top: 50px; font-size: 11pt; font-family: Calibri, sans-serif;">
															<strong>Thank you!</strong>
														</p>
														
														<p style="margin-top: 30px; font-size: 11pt; font-family: Calibri, sans-serif;">
															<strong>Kind Regards<br/>ACC</strong>
														</p>
													  </td>
													</tr>
												</tbody>
											 </table>
										   </td>
										</tr>
									 </table>	
								   </td>
								</tr>
							</table>				 
					</body>
				</html> 
			 ';
			 
	$subject_owner = "Requested for user access";
	
	sendMail($mailHost, $mailPort, $mailUser, $mailPassword, $mailSender, $email_user_owner, $subject_owner, $htmlbody_owner);
	
	
	
	$htmlbody_requester = '
			  <html lang="en">
				 <head>
				   <title>Password-Engine</title>
				</head>
                <body style="margin:0; padding:0; background:#f4f4f4">
				  <div class="content" id="wrapper">
					<div class="nw_layout_LAYOUT1">
					  <table align="center" border="0" cellpadding="0" cellspacing="0" class="CoverPage" id="CoverPage" style="" width="600">
						<tr>
						  <td id="header" valign="top" width="600" style="width: 100%;
							padding: 0px 0px 8px 0px;">
							<table id="nw_masthead_wrapper" class="nw_component_wrapper" cellpadding="0" cellspacing="0">
							   <tr>
								<td class="nw-componentSpacerMainCell">
									<table cellpadding="0" cellspacing="0" class="ContentBlock" id="masthead" style="margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;" width="100%">
									  <tr>
										<td class="nw-componentMainCell">
										   <img alt="" src="vois.jpg" width="600" height="301" /></a>
										</td>
									  </tr>
									</table>
								</td>
							  </tr>
							</table>
						  </td> 
						</tr>
						
						<tr>
						  <td id="main" valign="top" width="600" style="width: 100%; padding-left: 0px; padding-right: 0px; background-color: #ffffff;">
							<table id="nw_maintitle_wrapper" class="nw_component_wrapper" cellpadding="0" cellspacing="0" width="100%">
							  <tr>
								<td class="nw-componentSpacerMainCell">
								   <table cellpadding="0" cellspacing="0" class="ContentBlock" id="maintitle" style="margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;" width="100%">
									  <tr>
										 <td class="nw-componentMainCell">
											<table style="width: 100%;" border="0" cellpadding="0" cellspacing="0">
											   <tbody>
												 <tr>
													<td class="main_title" style="font-family: sans-serif; font-size: 16px; color: #FFFFFF; font-weight:300; font-style: normal; text-decoration: none; background-color: #000000; padding: 8px; border: 1px solid #FFFFFF;">Password Engine<br/></td>
												 </tr>
												</tbody>
											</table>
										  </td>
									  </tr>
									</table>
								</td>
							  </tr>
							</table>

							<table id="nw_maincontent_wrapper" class="nw_component_wrapper" cellpadding="0" cellspacing="0" width="100%">
								<tr>
								  <td class="nw-componentSpacerMainCell">
									 <table cellpadding="0" cellspacing="0" class="ContentBlock" id="maincontent" style="margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;" width="100%">
										<tr>
										  <td class="nw-componentMainCell">
											 <table style="width: 100%;" border="0" cellpadding="0" cellspacing="0">
												<tbody>
												   <tr>
													  <td class="main_content" style="font-size: 16px; color: #000000; font-weight: normal; font-style: normal; text-decoration: none; padding: 10px;">
														<p style="margin: 1.3rem 0rem; margin-top:12px; font-size: 9pt; font-family: Calibri, sans-serif;">
														  <span style="font-family: sans-serif; color: black;">Hello '.$requesterName.',</span>
														</p>
														
														<p style="margin: 1.3rem 0rem; font-size: 9pt; font-family: Calibri, sans-serif;">
															<span style="font-family: sans-serif; color: black;">Your request has been successfully submitted on portal & currently awaiting account owner approval.</span>
														</p>
														
														<p style="margin: 1.3rem 0rem; font-size: 9pt; font-family: Calibri, sans-serif;">
															<span style="font-family: sans-serif; color: black;">
															  Request detail: <br/>
															  User Name: '.$userName.'<br/>
															  Server Name: '.$serverName.'<br/>
															</span>
														</p>
														
														<p style="margin: 1.3rem 0rem; font-size: 9pt; font-family: Calibri, sans-serif;">
															<span style="font-family: sans-serif; color: black;">For any issue, please reach out to<a href="#" style="color: #000000c7">pe@vodafone.com.</a>
															</span>
														</p>
														
														<p style="margin-top: 50px; font-size: 11pt; font-family: Calibri, sans-serif;">
															<strong>Thank you!</strong>
														</p>
														
														<p style="margin-top: 30px; font-size: 11pt; font-family: Calibri, sans-serif;">
															<strong>Kind Regards<br/>ACC</strong>
														</p>
													  </td>
													</tr>
												</tbody>
											 </table>
										   </td>
										</tr>
									 </table>	
								   </td>
								</tr>
							</table>				 
					</body>
				</html> 
			 ';
			 
	$subject_requester = "Request for user access";
	
	sendMail($mailHost, $mailPort, $mailUser, $mailPassword, $mailSender, $requesterEmail, $subject_requester, $htmlbody_requester);
}	



	
if($_REQUEST['key']=='insertUser'){
	
	$htmlbody = '
			  <html lang="en">
				 <head>
				   <title>Password-Engine</title>
				</head>
                <body style="margin:0; padding:0; background:#f4f4f4">
				  <div class="content" id="wrapper">
					<div class="nw_layout_LAYOUT1">
					  <table align="center" border="0" cellpadding="0" cellspacing="0" class="CoverPage" id="CoverPage" style="" width="600">
						<tr>
						  <td id="header" valign="top" width="600" style="width: 100%;
							padding: 0px 0px 8px 0px;">
							<table id="nw_masthead_wrapper" class="nw_component_wrapper" cellpadding="0" cellspacing="0">
							   <tr>
								<td class="nw-componentSpacerMainCell">
									<table cellpadding="0" cellspacing="0" class="ContentBlock" id="masthead" style="margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;" width="100%">
									  <tr>
										<td class="nw-componentMainCell">
										   <img alt="" src="vois.jpg" width="600" height="301" /></a>
										</td>
									  </tr>
									</table>
								</td>
							  </tr>
							</table>
						  </td> 
						</tr>
						
						<tr>
						  <td id="main" valign="top" width="600" style="width: 100%; padding-left: 0px; padding-right: 0px; background-color: #ffffff;">
							<table id="nw_maintitle_wrapper" class="nw_component_wrapper" cellpadding="0" cellspacing="0" width="100%">
							  <tr>
								<td class="nw-componentSpacerMainCell">
								   <table cellpadding="0" cellspacing="0" class="ContentBlock" id="maintitle" style="margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;" width="100%">
									  <tr>
										 <td class="nw-componentMainCell">
											<table style="width: 100%;" border="0" cellpadding="0" cellspacing="0">
											   <tbody>
												 <tr>
													<td class="main_title" style="font-family: sans-serif; font-size: 16px; color: #FFFFFF; font-weight:300; font-style: normal; text-decoration: none; background-color: #000000; padding: 8px; border: 1px solid #FFFFFF;">Password Engine<br/></td>
												 </tr>
												</tbody>
											</table>
										  </td>
									  </tr>
									</table>
								</td>
							  </tr>
							</table>

							<table id="nw_maincontent_wrapper" class="nw_component_wrapper" cellpadding="0" cellspacing="0" width="100%">
								<tr>
								  <td class="nw-componentSpacerMainCell">
									 <table cellpadding="0" cellspacing="0" class="ContentBlock" id="maincontent" style="margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;" width="100%">
										<tr>
										  <td class="nw-componentMainCell">
											 <table style="width: 100%;" border="0" cellpadding="0" cellspacing="0">
												<tbody>
												   <tr>
													  <td class="main_content" style="font-size: 16px; color: #000000; font-weight: normal; font-style: normal; text-decoration: none; padding: 10px;">
														<p style="margin: 1.3rem 0rem; margin-top:12px; font-size: 9pt; font-family: Calibri, sans-serif;">
														  <span style="font-family: sans-serif; color: black;">Hello '.$f_name.' '.$f_name.'</span>
														</p>
														
														<p style="margin: 1.3rem 0rem; font-size: 9pt; font-family: Calibri, sans-serif;">
															<span style="font-family: sans-serif; color: black;">Your account has been successfully created on portal.</span>
														</p>
														
														<p style="margin: 1.3rem 0rem; font-size: 9pt; font-family: Calibri, sans-serif;">
															<span style="font-family: sans-serif; color: black;">
															  Login Credentials: <br/>
															  User Name : '.$email.' <br/>
															  Password : **Windows AD account Password** <br/>
															  URL to access portal : <a href="http://139.47.169.69/password-engine/">www.password-engine-vodafone.com</a>
															</span>
														</p>
														
														<p style="margin: 1.3rem 0rem; font-size: 9pt; font-family: Calibri, sans-serif;">
															<span style="font-family: sans-serif; color: black;">In case of any issue, please reach out to <a href="#" style="color: #000000c7">pe@vodafone.com</a>
															</span>
														</p>
														
														<p style="margin-top: 50px; font-size: 11pt; font-family: Calibri, sans-serif;">
															<strong>Thank you!</strong>
														</p>
														
														<p style="margin-top: 30px; font-size: 11pt; font-family: Calibri, sans-serif;">
															<strong>Kind Regards<br/>ACC</strong>
														</p>
													  </td>
													</tr>
												</tbody>
											 </table>
										   </td>
										</tr>
									 </table>	
								   </td>
								</tr>
							</table>				 
					</body>
				</html> 
			 ';
			 
	$subject = "Your are successfully created user on password portal";
	
	sendMail($mailHost, $mailPort, $mailUser, $mailPassword, $mailSender, $email, $subject, $htmlbody);
}





if($_REQUEST['key']=='UserServer'){
	$htmlbody = '
			 <html lang="en">
				 <head>
				   <title>Password-Engine</title>
				</head>
                <body style="margin:0; padding:0; background:#f4f4f4">
				  <div class="content" id="wrapper">
					<div class="nw_layout_LAYOUT1">
					  <table align="center" border="0" cellpadding="0" cellspacing="0" class="CoverPage" id="CoverPage" style="" width="600">
						<tr>
						  <td id="header" valign="top" width="600" style="width: 100%;
							padding: 0px 0px 8px 0px;">
							<table id="nw_masthead_wrapper" class="nw_component_wrapper" cellpadding="0" cellspacing="0">
							   <tr>
								<td class="nw-componentSpacerMainCell">
									<table cellpadding="0" cellspacing="0" class="ContentBlock" id="masthead" style="margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;" width="100%">
									  <tr>
										<td class="nw-componentMainCell">
										   <img alt="" src="vois.jpg" width="600" height="301" /></a>
										</td>
									  </tr>
									</table>
								</td>
							  </tr>
							</table>
						  </td> 
						</tr>
						
						<tr>
						  <td id="main" valign="top" width="600" style="width: 100%; padding-left: 0px; padding-right: 0px; background-color: #ffffff;">
							<table id="nw_maintitle_wrapper" class="nw_component_wrapper" cellpadding="0" cellspacing="0" width="100%">
							  <tr>
								<td class="nw-componentSpacerMainCell">
								   <table cellpadding="0" cellspacing="0" class="ContentBlock" id="maintitle" style="margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;" width="100%">
									  <tr>
										 <td class="nw-componentMainCell">
											<table style="width: 100%;" border="0" cellpadding="0" cellspacing="0">
											   <tbody>
												 <tr>
													<td class="main_title" style="font-family: sans-serif; font-size: 16px; color: #FFFFFF; font-weight:300; font-style: normal; text-decoration: none; background-color: #000000; padding: 8px; border: 1px solid #FFFFFF;">Password Engine<br/></td>
												 </tr>
												</tbody>
											</table>
										  </td>
									  </tr>
									</table>
								</td>
							  </tr>
							</table>

							<table id="nw_maincontent_wrapper" class="nw_component_wrapper" cellpadding="0" cellspacing="0" width="100%">
								<tr>
								  <td class="nw-componentSpacerMainCell">
									 <table cellpadding="0" cellspacing="0" class="ContentBlock" id="maincontent" style="margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;" width="100%">
										<tr>
										  <td class="nw-componentMainCell">
											 <table style="width: 100%;" border="0" cellpadding="0" cellspacing="0">
												<tbody>
												   <tr>
													  <td class="main_content" style="font-size: 16px; color: #000000; font-weight: normal; font-style: normal; text-decoration: none; padding: 10px;">
														<p style="margin: 1.3rem 0rem; margin-top:12px; font-size: 9pt; font-family: Calibri, sans-serif;">
														  <span style="font-family: sans-serif; color: black;">Hello '.$uName.',</span>
														</p>
														
														<p style="margin: 1.3rem 0rem; font-size: 9pt; font-family: Calibri, sans-serif;">
															<span style="font-family: sans-serif; color: black;">Your account has been successfully created on portal.</span>
														</p>
														
														<p style="margin: 1.3rem 0rem; font-size: 9pt; font-family: Calibri, sans-serif;">
															<span style="font-family: sans-serif; color: black;">
															  Login Credentials: <br/>
															  User Name : '.$email.' <br/>
															  Password : **Windows AD account Password** <br/>
															  URL to access portal : <a href="http://139.47.169.69/password-engine/">www.password-engine-vodafone.com</a>
															</span>
														</p>
														
														<p style="margin: 1.3rem 0rem; font-size: 9pt; font-family: Calibri, sans-serif;">
															<span style="font-family: sans-serif; color: black;">In case of any issue, please reach out to <a href="#" style="color: #000000c7">pe@vodafone.com</a>
															</span>
														</p>
														
														<p style="margin-top: 50px; font-size: 11pt; font-family: Calibri, sans-serif;">
															<strong>Thank you!</strong>
														</p>
														
														<p style="margin-top: 30px; font-size: 11pt; font-family: Calibri, sans-serif;">
															<strong>Kind Regards<br/>ACC</strong>
														</p>
													  </td>
													</tr>
												</tbody>
											 </table>
										   </td>
										</tr>
									 </table>	
								   </td>
								</tr>
							</table>				 
					</body>
				</html> 
			 ';
			 
	$subject = "Your are successfully created user on password portal";
	
	sendMail($mailHost, $mailPort, $mailUser, $mailPassword, $mailSender, $uEmail, $subject, $htmlbody);
}





function sendMail($host, $port, $userName, $password, $sender, $email, $subject, $htmlbody){
	
	$mail = new PHPMailer;
	$mail->isSMTP();
	$mail->SMTPDebug = 0;
	$mail->Host = $host;
	$mail->Port = (int)$port;
	
	if(isset($userName) && isset($password)){
	
		$mail->SMTPSecure = 'tls';
	    $mail->SMTPAuth = true;
	    $mail->Username = $userName;
	    $mail->Password = $password;
	}
	
	$mail->setFrom($sender);
	$mail->addAddress($email);
    $mail->Subject = $subject;
	$mail->msgHTML($htmlbody);
	$mail->send();
	
	if (!$mail->send()) {
		echo "Mailer Error: ".$mail->ErrorInfo;
	}
}

?>