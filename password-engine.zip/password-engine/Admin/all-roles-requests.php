<?php
$table_name = "role_requests";
$alert = "";

include('controller/select.php');
include("includes/header.php");

?>


<div class="page-wrapper">
	<div class="content container-fluid">
	
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Roles Requested</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Roles Requested</li>
					</ol>
				</div>
			</div>
		</div>
	    
		<div class="page-header">
			<div class="row">
			  <div class="col-12">
				<?php echo $alert; ?>
			  </div>
			</div>
			
			<div class="row">
			   <div class="col-sm-12">
				  <div class="card card-table">
					<div class="card-body booking_card">
						<div class="table-responsive">
							<table class="datatable table table-stripped table table-hover table-center mb-0">
								<thead>
									<tr>
										<th>#</th>
										<th>User Name</th>
										<th>Requested Role</th>
										<th>Market</th>
										<th>Comments</th>
										<th>Created On</th>
										<th>Updated On</th>
										<th class="text-right pr-5">Actions</th>
									</tr>
								</thead>
								<tbody>
								 <?php
								   foreach( $result as $key=>$row ){ ?>
									<tr>
										<td><?=++$key?></td>
										<td><?=$row["f_name"].' '.$row["l_name"]?></td>
										
										<td><?=$row["role"]?></td>
										
										<td><?=$row["market"]?></td>
										
										<td><?=$row["description"]?></td>
										
										<td><?=date('d-M-Y', strtotime($row["created_at"]))?></td>
										
										<td><?=date('d-M-Y', strtotime($row["updated_at"]))?></td>
										
										<!-- 
										<td>
											<select id="updateStatus" class="form-control" onchange="updateStatus(this, <?=$row['id']?>)">  
												<option value="Pending"<?php if($row['is_pending']==1){ echo "disabled selected"; } ?>>Pending</option>
												
												<option value="Approved"<?php if($row['is_approved']==1){ echo "disabled selected"; } ?>>Approved</option> 
												
												<option value="Declined"<?php if($row['is_declined']==1){ echo "disabled selected"; } ?>>Declined</option> 
											</select>  
										</td>
										-->
									
										<td class="text-right">
										  <div class="btn-group open">
											  <a class="btn <?=$btnColor?>" href="#"><i class="<?=$icon?> fa-fw"></i><?=$status?>
											  </a>
											  <a class="btn <?=$btnColor?>" data-toggle="dropdown" href="#">
												<span class="fa fa-caret-down" title="Toggle dropdown menu"></span>
											  </a>
											  
											  <div class="dropdown-menu dropdown-menu-right">
												  
												  <button class="dropdown-item" onclick="updateStatus('Pending', <?=$row['id']?>)" <?php if($row['is_pending']==1){ echo "disabled"; } ?>>
													<i class="fa fa-clock-o m-r-5 text-warning"></i>Pending
												  </button>
												  
												  <button class="dropdown-item" onclick="updateStatus('Approved', <?=$row['id']?>)" <?php if($row['is_approved']==1){ echo "disabled selected"; } ?>>
												   <i class="fa fa-check-square-o m-r-5 text-success"></i>Approved
												  </button>
												  
												  <button class="dropdown-item" onclick="updateStatus('Declined', <?=$row['id']?>)" <?php if($row['is_declined']==1){ echo "disabled selected"; } ?>>
													<i class="fa fa-ban m-r-5 text-danger"></i>Declined
												  </button>
												  
												</div>
											 </td>
										 </tr>
									   <?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				 </div>
			  </div>
		  </div>
	   </div>
   </div>
</div>
	
	
<!-- jQuery -->
<script>
	var element = document.getElementById("RoleRequests");
	   element.classList.add("active");
</script>

<?php include("includes/footer.php"); ?>
	
