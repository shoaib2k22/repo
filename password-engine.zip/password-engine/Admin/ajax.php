<?php
include("includes/header.php");
include("includes/footer.php");
error_log("Error messagwwe\n",3,"../php.log");
?>

<script>
$.ajax({
	 url:'http://localhost/password-engine/api/single-user.php',
	 type:'POST',
	 data:{
		   id:1,
		 },
	 success:function(result){
		console.log(result);
	 }
 });
</script>