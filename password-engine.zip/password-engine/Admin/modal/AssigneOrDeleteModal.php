<?php
include('../controller/getAssigneOrDelete.php');
?>


<?php 
 if($_REQUEST['key'] == 'RoleGrant'){?>
		<div class="modal fade delete-modal" id="addFormModal">
		   <div class="modal-dialog modal-dialog-centered">
			  <div class="modal-content">

				  <!-- Modal Header -->
				  <div class="modal-header">
					<h4 class="modal-title">Assign Role</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				  </div>

				  <!-- Modal body -->
				  <div class="modal-body">
					<form id="addFormData">
						<div class="row formtype">
							<div class="col-md-12">
							   <div class="form-group">
								  <label>Ticket No. <span class="text-danger">*</span></label>
								  <input class="form-control" type="text" id="ticket" name="ticket" placeholder="Ticket number" required />
								  <div id="ErrorTicket" class="form-control-error"></div>
							   </div>
							</div>
							
							<div class="col-md-12">
								<div class="form-group">
									<label>Select Role</label>
									<select class="form-control" id="role" name="role">
										<option value="" disabled selected>Select Role</option>
										  <?php while($rRow = $rResult->fetch_assoc()){ ?>  
											<option value="<?php echo $rRow['id']; ?>"> <?php echo $rRow['role']; ?> </option>  
										  <?php }?>
									</select>
									<div id="ErrorRole" class="form-control-error"></div>
								</div>
							</div>
							
							<div class="col-md-6">
							  <div class="form-group">
								<label>Status</label>
								  <select class="form-control" id="status" name="status">
									  <option value="1">Active</option>
									  <option value="0">Inactive</option>
								  </select>
								  <div id="ErrorStatus" class="form-control-error"></div>
							  </div>
							</div>
							
							<div class="col-md-6">
							  <div class="form-group">
								<label>Action</label>
								  <select class="form-control" id="action" name="action">
									  <option value="add">Add</option>
									  <option value="delete">Delete</option>
								  </select>
								  <div id="ErrorAction" class="form-control-error"></div>
							  </div>
							</div>
							
						  </div>
						</div>
						<div class="modal-footer float-right">
						  <button type="submit" class="btn btn-danger" onclick="AssigneOrDelete('&uID=<?=$uID;?>&uMID=<?=$uMID;?>&key=RoleGrant')">Save</button>
						  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
					   </div>
					</form>
				  </div>
				  <!-- Modal body end-->
			  </div>
		   </div>
		</div>
<?php 
    } ?>
	
	

<?php 
 if($_REQUEST['key'] == 'ServerGrant'){?>
		<div class="modal fade delete-modal" id="addFormModal">
		   <div class="modal-dialog modal-dialog-centered">
			  <div class="modal-content">

				  <!-- Modal Header -->
				  <div class="modal-header">
					<h4 class="modal-title">Assign Server</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				  </div>

				  <!-- Modal body -->
				  <div class="modal-body">
					<form id="addFormData">
						<div class="row formtype">
							<div class="col-md-12">
							   <div class="form-group">
								  <label>Ticket No. <span class="text-danger">*</span></label>
								  <input class="form-control" type="text" id="ticket" name="ticket" placeholder="Ticket number" required />
								  <div id="ErrorTicket" class="form-control-error"></div>
							   </div>
							</div>
							
							<div class="col-md-12">
								<div class="form-group">
									<label>Select Sever</label>
									<select class="form-control" id="server" name="server" onchange="getServerUser(this.value)">
										<option value="" disabled selected>Select Server</option>
										  <?php while($rRow = $rResult->fetch_assoc()){ ?>  
											<option value="<?php echo $rRow['id']; ?>"> <?php echo $rRow['host_name']; ?> </option>  
										<?php }?>
									</select>
									<div id="ErrorServer" class="form-control-error"></div>
								</div>
							</div>
							
							<div class="col-md-12">
							  <div class="form-group">
							    <div id="GetServerUser"></div>
							  </div>
							</div>
							
							<div class="col-md-12">
							  <div class="form-group">
								<label>Action</label>
								  <select class="form-control" id="action" name="action">
									  <option value="add">Add</option>
									  <option value="delete">Delete</option>
								  </select>
								  <div id="ErrorAction" class="form-control-error"></div>
							  </div>
							</div>
							
						  </div>
						</div>
						<div class="modal-footer float-right">
						  <button type="submit" class="btn btn-danger" onclick="AssigneOrDelete('&uID=<?=$uID;?>&uMID=<?=$uMID;?>&key=ServerGrant')">Save</button>
						  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
					   </div>
					</form>
				  </div>
				  <!-- Modal body end-->
			  </div>
		   </div>
		</div>
<?php 
    } ?>
	
	
	
<?php 
 if($_REQUEST['key'] == 'Connect'){?>	
		<div class="modal fade delete-modal" id="addFormModal">
		   <div class="modal-dialog modal-dialog-centered">
			  <div class="modal-content">

				  <!-- Modal Header -->
				  <div class="modal-header">
					<h4 class="modal-title">Assign Server</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				  </div>

				  <!-- Modal body -->
				  <div class="modal-body">
					<form id="addFormData">
						
						<div class="row formtype">
							<div class="col-md-12">
							   <div class="form-group">
								  <label>Ticket No. <span class="text-danger">*</span></label>
								  <input class="form-control" type="text" id="ticket" name="ticket" placeholder="Ticket number" required />
								  <div id="ErrorTicket" class="form-control-error"></div>
							   </div>
							</div>
							
							<div class="col-md-12">
								<div class="form-group">
									<label>Select Server</label>
									<select class="form-control" id="server" name="server">
										<option value="" disabled selected>Select Server</option>
										  <?php while($sRow = $sResult->fetch_assoc()){ ?>  
											<option value="<?php echo $sRow['id']; ?>"> <?php echo $sRow['host_name']; ?> </option>  
										  <?php }?>
									</select>
									<div id="ErrorServer" class="form-control-error"></div>
								</div>
							</div>
							
							<div class="col-md-6">
							  <div class="form-group">
								<label>Status</label>
								  <select class="form-control" id="status" name="status">
									  <option value="1">Active</option>
									  <option value="0">Inactive</option>
								  </select>
								  <div id="ErrorStatus" class="form-control-error"></div>
							  </div>
							</div>
							
							<div class="col-md-6">
							  <div class="form-group">
								<label>Action</label>
								  <select class="form-control" id="action" name="action">
									  <option value="add">Add</option>
									  <option value="delete">Delete</option>
								  </select>
								  <div id="ErrorAction" class="form-control-error"></div>
							  </div>
							</div>
							
						  </div>
						</div>
						<div class="modal-footer float-right">
						  <button type="submit" class="btn btn-danger" onclick="AssigneOrDelete('&rID=<?=$rID;?>&rMID=<?=$rMID;?>&key=Connect')">Save</button>
						  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
					   </div>
					</form>
				  </div>
				  <!-- Modal body end-->
			  </div>
		   </div>
		</div>
<?php 
    } ?>


<?php 
 if($_REQUEST['key'] == 'ServerUser'){?>	
		<div class="modal fade delete-modal" id="addFormModal">
		   <div class="modal-dialog modal-dialog-centered">
			  <div class="modal-content">

				  <!-- Modal Header -->
				  <div class="modal-header">
					<h4 class="modal-title">Add / Remove User</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				  </div>

				  <!-- Modal body -->
				  <div class="modal-body">
					<form id="addFormData">
						
						<div class="row formtype">
							<div class="col-md-12">
							   <div class="form-group">
								  <label>Ticket No. <span class="text-danger">*</span></label>
								  <input class="form-control" type="text" id="ticket" name="ticket" placeholder="Ticket number" required />
								  <div id="ErrorTicket" class="form-control-error"></div>
							   </div>
							</div>
							
							<div class="col-md-12">
								<div class="form-group">
									<label>Select User</label>
									<select class="form-control" id="user" name="user">
										<option value="" disabled selected>Select User</option>
										  <?php while($uRow = $uResult->fetch_assoc()){ ?>  
											<option value="<?php echo $uRow['id']; ?>"> <?php echo $uRow['email']; ?> </option>  
										  <?php }?>
									</select>
									<div id="ErrorUser" class="form-control-error"></div>
								</div>
							</div>
							
							<div class="col-md-12">
								<div class="form-group">
									<label>User Name<span class="text-danger">*</span></label>
									<input class="form-control" type="text" id="userName" name="userName" placeholder="Add user name">
									<div id="ErrorUserName" class="form-control-error"></div>
								</div>
							</div>
							
							<div class="col-md-6">
							  <div class="form-group">
								<label>Status</label>
								  <select class="form-control" id="status" name="status">
									  <option value="1">Active</option>
									  <option value="0">Inactive</option>
								  </select>
								  <div id="ErrorStatus" class="form-control-error"></div>
							  </div>
							</div>
							
							<div class="col-md-6">
							  <div class="form-group">
								<label>Action</label>
								  <select class="form-control" id="action" name="action">
									  <option value="add">Add</option>
									  <option value="delete">Delete</option>
								  </select>
								  <div id="ErrorAction" class="form-control-error"></div>
							  </div>
							</div>
							
						  </div>
						</div>
						<div class="modal-footer float-right">
						  <button type="submit" class="btn btn-danger" onclick="AssigneOrDelete('&server=<?=$sID;?>&key=UserServer')">Save</button>
						  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
					   </div>
					</form>
				  </div>
				  <!-- Modal body end-->
			  </div>
		   </div>
		</div>
<?php 
    } ?>
	

<script> 
$(document).ready(function() {
  $('#server').select2({
		placeholder: "Select Server",
		allowClear: true
	});
	
	$('#s_user').select2({
		placeholder: "Select User",
		allowClear: true
	});
});
	   
</script>

