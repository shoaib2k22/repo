<?php

$modalName = "addModal";

include('../controller/modal.php');

$mSql = "SELECT * FROM markets WHERE status = 1 ORDER BY market";
$mResult = $conn->query($mSql);

?>


<?php
if($key == 'addAdmin'){?>
	<div class="modal fade delete-modal" id="addFormModal">
	  <div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add Admin</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertAdmin">
				<div class="row formtype">
					<div class="col-md-6">
						<div class="form-group">
							<label>First Name</label>
							<input class="form-control" type="text" name="f_name">
							<div id="ErrorFName" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Last Name</label>
							<input class="form-control" type="text" name="l_name">
							<div id="ErrorLName" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Email</label>
							<input class="form-control" type="email" name="email">
							<div id="ErrorEmail" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Mobile Number</label>
							<input class="form-control" type="number" name="mobile">
							<div id="ErrorMobile" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Select Market</label>
							<select class="form-control" name="market">
								<option value="" disabled selected>Select Market</option>
								  <?php while($mRow = $mResult->fetch_assoc()){ ?>  
									<option value="<?php echo $mRow['id']; ?>"> <?php echo $mRow['market']; ?> </option>  
								  <?php }?>
							</select>
							<div id="ErrorMarket" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
						  <div id="ErrorStatus" class="form-control-error"></div>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-danger" onclick="addOnDB('insertAdmin')">Save</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>





<?php
if($key == 'addRole'){?>
	<div class="modal fade delete-modal" id="addFormModal">
	  <div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add Role</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertRole">
				<div class="row formtype">
				    <!--
					<div class="col-md-12">
						<div class="form-group">
							<label>Select Market</label>
							<select class="form-control" name="market">
								<option value="" disabled selected>Select Market</option>
								  <?php while($mRow = $mResult->fetch_assoc()){ ?>  
									<option value="<?php echo $mRow['id']; ?>"> <?php echo $mRow['market']; ?> </option>  
								  <?php }?>
							</select>
							<div id="ErrorMarket" class="form-control-error"></div>
						</div>
					</div>
					-->
					<div class="col-md-12">
						<div class="form-group">
							<label>Role Name</label>
							<input class="form-control" type="text" name="role" placeholder="Add role name">
							<div id="ErrorRole" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
						  <div id="ErrorStatus" class="form-control-error"></div>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-danger" onclick="addOnDB('insertRole')">Save</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>






<?php
if($key == 'addMarket'){?>
	<div class="modal fade delete-modal" id="addFormModal">
	  <div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add Market</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertMarket">
				<div class="row formtype">
					<div class="col-md-12">
						<div class="form-group">
							<label>Market</label>
							<input class="form-control" type="text" name="market">
							<div id="ErrorMarket" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
						  <div id="ErrorStatus" class="form-control-error"></div>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-danger" onclick="addOnDB('insertMarket')">Save</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>





<?php
if($key == 'addOwner'){?>
	<div class="modal fade delete-modal" id="addFormModal">
	  <div class="modal-dialog">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add Owner</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertOwner">
				<div class="row formtype">
				    <div class="col-md-12">
						<div class="form-group">
							<label>Select Market</label>
							<select class="form-control" name="market">
								<option value="" disabled selected>Select Market</option>
								  <?php while($mRow = $mResult->fetch_assoc()){ ?>  
									<option value="<?php echo $mRow['id']; ?>"> <?php echo $mRow['market']; ?> </option>  
								  <?php }?>
							</select>
							<div id="ErrorMarket" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Owner</label>
							<input class="form-control" type="text" name="owner">
							<div id="ErrorOwner" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Email</label>
							<input class="form-control" type="email" name="email">
							<div id="ErrorEmail" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
						  <div id="ErrorStatus" class="form-control-error"></div>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-danger" onclick="addOnDB('insertOwner')">Save</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>



<?php
if($key == 'addServer'){ ?>
	<div class="modal fade delete-modal" id="addFormModal">
	  <div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add Server</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertServer">
				<div class="row formtype">
				    
					 <div class="col-md-12">
					   <div class="form-group">
						  <label>Ticket No. <span class="text-danger">*</span></label>
						  <input class="form-control" type="text" id="ticket" name="ticket" placeholder="Ticket number" required />
						  <div id="ErrorTicket" class="form-control-error"></div>
					   </div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Server Name</label>
							<input class="form-control icon-rtl" type="text" name="host" id="host" placeholder="Server Name" onfocusout="validateServer()"/>
							<div id="ErrorHost" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>IP Address</label>
							<input class="form-control" type="text" name="ip" placeholder="IP Address">
							<div id="ErrorIp" class="form-control-error"></div>
						</div>
					</div>
					<!--<div class="col-md-6">
						<div class="form-group">
							<label>Port</label>
							<input class="form-control" type="number" name="port">
							<div id="ErrorPort" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Password</label>
							<input class="form-control" type="password" name="password">
							<div id="ErrorPassword" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Confirm Password</label>
							<input class="form-control" type="password" name="confirm_password">
							<div id="ErrorConfirmPassword" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label>Os Type</label>
						  <select class="form-control" id="os_type" name="os_type">
							  <option value="windows">Windows</option>
							  <option value="linux">Linux</option>
						  </select>
						  <div id="ErrorOs" class="form-control-error"></div>
					  </div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
						  <div id="ErrorStatus" class="form-control-error"></div>
					  </div>
					</div>-->
					
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-danger" id="addServer" onclick="addOnDB('insertServer')">Save</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>




<?php
if($key == 'addUser'){?>
	<div class="modal fade delete-modal" id="addFormModal">
	  <div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add User</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="insertUser">
				<div class="row formtype">
				    <div class="col-md-6">
					   <div class="form-group">
						  <label>Ticket No. <span class="text-danger">*</span></label>
						  <input class="form-control" type="text" id="ticket" name="ticket" placeholder="Ticket number" required />
						  <div id="ErrorTicket" class="form-control-error"></div>
					   </div>
					</div>
				    <!--
					<div class="col-md-12">
						<div class="form-group">
							<label>Select Market</label>
							<select class="form-control" name="market">
								<option value="" disabled selected>Select Market</option>
								  <?php while($mRow = $mResult->fetch_assoc()){ ?>  
									<option value="<?php echo $mRow['id']; ?>"> <?php echo $mRow['market']; ?> </option>  
								  <?php }?>
							</select>
							<div id="ErrorMarket" class="form-control-error"></div>
						</div>
					</div>
					-->
				    <div class="col-md-6">
						<div class="form-group">
							<label>Unix ID <span class="text-danger">*</span></label>
							<input class="form-control" type="text" name="unix_id">
							<div id="ErrorUnix" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>First Name</label>
							<input class="form-control" type="text" name="f_name">
							<div id="ErrorFName" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Last Name</label>
							<input class="form-control" type="text" name="l_name">
							<div id="ErrorLName" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Email <span class="text-danger">*</span></label>
							<input class="form-control" type="email" name="email">
							<div id="ErrorEmail" class="form-control-error"></div>
						</div>
					</div>
					<!--
					<div class="col-md-6">
						<div class="form-group">
							<label>Mobile</label>
							<input class="form-control" type="text" name="mobile">
							<div id="ErrorMobile" class="form-control-error"></div>
						</div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label>Gender</label>
						  <select class="form-control" id="gender" name="gender">
							  <option value="male">Male</option>
							  <option value="female">Female</option>
							  <option value="other">Other</option>
						  </select>
						  <div id="ErrorGender" class="form-control-error"></div>
					  </div>
					</div>
					-->
				    <div class="col-md-12">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" id="status" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
						  </select>
						  <div id="ErrorStatus" class="form-control-error"></div>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-danger" onclick="addOnDB('insertUser')">Save</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>
