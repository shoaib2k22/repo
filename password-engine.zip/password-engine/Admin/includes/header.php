<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<title>Vodafone Password Engine</title>

	<!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="../img/logo.png">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">

	<!-- Fontawesome CSS -->
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/plugins/datatables/datatables.min.css">
	<!-- Feathericon CSS -->
	<link rel="stylesheet" href="assets/css/feathericon.min.css">

	<link rel="stylesheet" href="assets/plugins/morris/morris.css">

	<!-- Main CSS -->
	<link rel="stylesheet" href="assets/css/style.css">
	
	 <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet"/>
	
	<style>
	.select2-container {
		box-sizing: border-box;
		display: block;
		margin: 0;
		position: relative;
		vertical-align: middle;
		width:100% !important;
	}
	
	.select2-container--default .select2-selection--single .select2-selection__clear {
		cursor: pointer;
		float: right;
		font-weight: bold;
		display: none;
	}
	
	.select2-container--default .select2-selection--single .select2-selection__placeholder {
		color: #333;
		font-size: 15px;
	}

    .select2-container--default .select2-selection--single {
		background-color: #fff;
		background-clip: padding-box;
		border: 1px solid #ced4da;
		border-radius: 0.25rem;
	}
	
	.select2-container .select2-selection--single {
		height: 40px;
	}
	
	.select2-container--default .select2-selection--single .select2-selection__rendered {
		color: #444;
		line-height: 40px;
	}
	
	.select2-container--default .select2-selection--single .select2-selection__arrow {
		height: 40px;
	}
	
	.select2-container .select2-selection--single .select2-selection__rendered {
		padding: 0rem 0.75rem;
	}
	
    @media (min-width: 992px){
		.modal-sh{
			max-width: 950px;
		}
	}
	 
	.dataTables_length select, .dataTables_filter input {
		border: 0;
		border-bottom:1px solid #e0e0e0;
		border-radius:0;
	}
	
	.dataTables_length select:focus, .dataTables_filter input:focus {
		outline: none;
		border-bottom:1px solid #fb9678;
		transition-duration: 0.3s;
	}
	.btn-status{
		padding: 0rem 1rem;
		font-weight:100;
	}
	#delete_asset form{
		display:inline-block;
	}
	.form-group {
		margin-bottom: 0rem;
		margin-top: 1rem;
    }
	.modal-body {
		padding: 1rem 2rem;
	}
	
	.sidebar-txt{
		padding:0px;
		font-size:10px;
		margin: 0;
		padding-bottom: 10px;
		/*color: #6c757d;*/
        font-weight: 400;
	}
	.mini-sidebar .sidebar-menu > ul > li > a {
		padding: 0px;
		padding-top: 5px;
	}
	.sidebar-menu {
		padding: 0px 0 0 1px;
	}
	
	.sidebar-menu ul {
		font-size: 15px;
		list-style-type: none;
		padding: 0;
		position: relative;
		margin-right: 0px;
	}
	
	
	.list-divider {
		border-bottom: 1px solid #edf2f9;
		height: 0px !important;
	}
	
	.sidebar {
		background-color: #fff;
		bottom: 0;
		left: 0;
		margin-top: 0;
		position: fixed;
		top: 66px;
		transition: all 0.2s ease-in-out 0s;
		width: 78px;
		z-index: 1001;
	}
	
	.page-wrapper {
		margin-left: 80px;
		padding-top: 32px;
		position: relative;
		transition: all 0.4s ease;
		background-color: #f2f5fa;
	}
	
	.header .header-left {
		float: left;
		height: 65px;
		padding: 0 0px;
		position: relative;
		text-align: center;
		width: 78px;
		background-color: #000;
	}
	
	.submenu_class {
		border-left: 1px solid #dfdfdf;
		position: relative;
		margin-left: 0px;
	}
	
	.sidebar-menu ul ul a {
		display: block;
		font-size: 14px;
		padding: 10px 0px 10px 0px;
		position: relative;
		border-top: 1px solid #f0eded;
	}
	
	
	.sidebar-menu ul ul a:before {
		display:none;
	}
	

	
	.sidebar-menu ul ul a {
		display: block;
		font-size: 14px;
		padding: 10px 0px 0px 0px;
		position: relative;
		border-top: 1px solid #f0eded;
	}
	
	.header {
		left: 0;
		position: fixed;
		right: 0;
		top: 0;
		z-index: 1001;
		height: 65px;
		background-color: #000;
		padding: 0 10px 0 0;
		border-bottom: 1px solid #e6010100;
		box-shadow: 0px 2px 8px 1px #887b7b6e;
	}
	
	.user-menu {
		float: right;
		margin: 0px;
		position: relative;
		z-index: 99;
		color: #ffffff;
	}
	
	.user-menu.nav > li > a {
		color: #fff;
	}
	

	
	.header .has-arrow .dropdown-toggle:after {
		border-bottom: 2px solid #fff;
		border-right: 2px solid #fff;
	}
	
	
	.page-titles {
		background: #dddddd;
		padding: 0px 0px;
		/*box-shadow: 0 1px 4px 0 rgb(0 0 0 / 10%);*/
		/* margin: 0 -31px 0px -31px; */
		line-height: 2rem;
		/* margin-bottom: 2rem; */
		/* border-left: 6px solid #f8f2f2; */
		padding-right: 15px;
		left: 94px;
		position: fixed;
		right: 16px;
		top: 66px;
		z-index: 100;
	}
	
	.page-wrapper > .content {
		padding: 0rem 1.5rem 0;
		/* margin-top: 35px; */
		padding-bottom: 0.5rem;
		padding-top: 7rem;
	}
	
	.breadcrumb {
		display: -ms-flexbox;
		display: flex;
		-ms-flex-wrap: wrap;
		flex-wrap: wrap;
		padding: 0.75rem 0rem;
		margin-bottom: 0rem;
		list-style: none;
		background-color: #e9ecef00;
		border-radius: 0rem;
		font-size: 12px;
	}
	
	.text-themecolor{
		font-size: 20px;
		margin: 0 !important;
	}
	
	.breadcrumb-item+.breadcrumb-item {
		padding-left: 0.5rem;
		color: #e60101;
	}
	
	.slimScrollBar{
		background: rgb(97 89 89) !important;
        width: 4px !important;
	}
	
	.form-control-error{
		font-size:12px;
		text-align:start;
		font-weight:400;
		color:#e84646 !important;
	}
	
	.top-admin{
		line-height: 60px;
		padding-left: 10px;
		color: #fff !important;
		font-size: 18px;
	}
	
	#addServer{
		display:none;
	}
	
	.h6, h6, .btn, body {
		font-size: 0.8rem;
	}

	.header {
	   background-color: #000000 !importanr;
	}
	
	.table {
		color: #555;
		font-size: 13px;
	}
	
	
	@media only screen and (max-width: 991.98px){
		.page-wrapper {
			margin-left: 0 !important;
			padding-left: 0;
			padding-right: 0;
			-webkit-transition: all 0.4s ease;
			-moz-transition: all 0.4s ease;
			transition: all 0.4s ease;
		}
	}
	
	
	/* width */
	::-webkit-scrollbar {
	  width: 10px;
	  height:10px;
	}
	
	::-webkit-scrollbar-button {
		height: 1px;
	}

	/* Track */
	::-webkit-scrollbar-track {
	  background: #f1f1f1; 
	}
	 
	/* Handle */
	::-webkit-scrollbar-thumb {
	  background: #888; 
	}

	/* Handle on hover */
	::-webkit-scrollbar-thumb:hover {
	  background: #555; 
	}
	
	
	#loaderImg{
		position: absolute;
		bottom: 50%;
		left: 50%;
		transform: translate(-25%, 35%);
		z-index: 99999;
		display:none;
	}
	#loaderImg img{
	   width:50%;
	}
	
	.sidebar {
		 top: 65px;
		 background: linear-gradient(270deg,#e60000 10%,#900);
		 background: #cb0505;
	}
	
	.sidebar-txt, .sidebar-menu ul li a i {
      color: #fff;
    }
	
	#sidebar-menu ul .active {
		color: #ffffff !important;
		border-left: 7px solid #ffffff;
		margin-right: 7px !important;
	}
	
	.sidebar-txt {
		padding-bottom: 5px;
	}
	
	.sidebar-menu ul li a i{
		transition: transform .2s;
		text-align: center;
		
	}
	
	#sidebar-menu ul li{
		transition: transform .2s;
		text-align: center;
		padding-top: 10px;
		padding-bottom: 10px;
	}
	
	#sidebar-menu ul li:first-child{
		padding-top: 20px;
	}
	
	#sidebar-menu ul li:hover{
		transform:scale(1.2);
	}
	#sidebar-menu ul .active{
		transform:scale(1.2);
	}
	.h1, .h2, .h3, .h4, .h5, .h6, h1, h2, h3, h4, h5, h6 {
		margin-bottom: 0.5rem;
		font-weight: 200;
		line-height: 1.2;
	}
	table th:hover{
		color: #e84646;
		border-bottom: 1px solid #e84646 !important;
		transform: scaleX(1);
	}
	
	
	.table th{
		color: #000;
		font-size: 13px;
		
	}
	
	table .sorting_asc{
		color: #e84646;
		border-bottom: 1px solid #e84646 !important;
	}
	
	
	
	</style>

</head>

<body>
	<!-- Main Wrapper -->
	<div class="main-wrapper">
	
	   <?php include("includes/topbar.php"); ?>
	   
		<?php include("includes/sidebar.php"); ?>