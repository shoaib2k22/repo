<?php
$table_name = "passwordEncryption";
$alert = "";

include('controller/select.php');
include("includes/header.php");
?>

<style>
.source, .target{
	background: #f1f1f1;
    margin: 5px;
    padding-bottom: 20px;
    border-radius: 4px;
}

.source-heading, .target-heading{
	margin: 20px 5px 10px 5px;
}

</style>




<div class="page-wrapper">
	<div class="content container-fluid">
	  
	   <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Code Level Password Encryption</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-2">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Code Level Password Encryption</li>
					</ol>
					<!--<button class="btn btn-danger float-right veiwbutton ml-3" onclick="getForm('addServer')">Add Server</button>
					<button class="btn btn-primary float-right veiwbutton ml-3" onclick="AddOrDeleteServerUserForm('ServerUser')">Add / Remove User</button>-->
				</div>
			</div>
		</div>
		
		<div class="page-header">
			<div class="row">
			  <div class="col-12">
				<?php echo $alert; ?>
			  </div>
			</div>
			
			<div class="row">
			   <div class="col-sm-12">
				  <div class="card card-table">
					 <div class="card-body booking_card">
						<form id="addFormData">
								<div class="row formtype">
									<div class="col-md-12">
									   <div class="form-group">
										  <label>Reference Request ID<span class="text-danger">*</span></label>
										  <input class="form-control" type="text" id="ticket" name="ticket" placeholder="Ticket number" required />
										  <div id="ErrorTicket" class="form-control-error"></div>
									   </div>
									</div>
								</div>
								
								<p class="source-heading">Fill Source Details </p>
								<div class="source row formtype">
									<div class="col-md-6">
										<div class="form-group">
											<label>Select Source ServerName <span class="text-danger">*</span></label>
											<select class="form-control" id="sourceServer" name="sourceServer">
												<option value="" disabled selected>Select</option>
												  <?php while($sRow = $sResult->fetch_assoc()){ ?>  
													<option value="<?php echo $sRow['id']; ?>"> <?php echo $sRow['host_name']; ?> </option>  
												  <?php }?>
											</select>
											<div id="ErrorSourceServer" class="form-control-error"></div>
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Source UserName<span class="text-danger">*</span></label>
											<input class="form-control" type="text" id="sourceUser" name="sourceUser" placeholder="Source User Name">
											<div id="ErrorSourceUser" class="form-control-error"></div>
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Source Account Type<span class="text-danger">*</span></label>
											<select class="form-control" id="sourceAccountType" name="sourceAccountType">
												<option value="" disabled selected>Select</option>
												<option value="1">Service</option>
												<option value="2">Funnctional</option>
												<option value="3">Local</option>
											</select>
											<div id="ErrorAccountType" class="form-control-error"></div>
										</div>
									</div>
									
									<div class="col-md-12">
										<div class="form-group">
											<label>Source UserName SSH Key<span class="text-danger">*</span></label>
											<textarea class="form-control" type="text" id="sourceSSHKey" name="sourceSSHKey" placeholder="Add SSH Key"></textarea>
											<div id="ErrorSSH" class="form-control-error"></div>
										</div>
									</div>
								</div>
								
								<p  class="target-heading">Fill Target Details</p>		
								<div class="target row formtype">
									<div class="col-md-6">
										<div class="form-group">
											<label>Select Target ServerName <span class="text-danger">*</span></label>
											<select class="form-control" id="targetServer" name="targetServer">
												<option value="" disabled selected>Select</option>
												  <?php while($tRow = $tResult->fetch_assoc()){ ?>  
													<option value="<?php echo $tRow['id']; ?>"> <?php echo $tRow['host_name']; ?> </option>  
												  <?php }?>
											</select>
											<div id="ErrorTargetServer" class="form-control-error"></div>
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Target UserName<span class="text-danger">*</span></label>
											<input class="form-control" type="text" id="targetUser" name="targetUser" placeholder="Target User Name">
											<div id="ErrorTargetUser" class="form-control-error"></div>
										</div>
									</div>
								</div>
							</div>
							<div class="modal-footer float-right">
							  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
							  <button type="button" class="btn btn-danger" onclick="addSSHKey('&key=AddUserServer')">Save</button>
							  <!--<button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>-->
						   </div>
						</form>
						
					</div>
				 </div>
			 </div>
		  </div>
	  </div>
   </div>
</div>
	
	
	
<!-- Modal's -->
 <div id="getUserModal"></div>
 <div id="getFormModal"></div>
 <div id="getStatusModal"></div>
<!-- Model's -->


<!-- jQuery -->
<script>  
	var element = document.getElementById("passwordEncryption");
	   element.classList.add("active");
	  
</script>
<?php include("includes/footer.php"); ?>
	
