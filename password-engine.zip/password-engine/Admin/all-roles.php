<?php
define('TITLE', 'Roles');
define('PAGE', 'Role');

$table_name = "roles";
$alert = "";

include('controller/select.php');
include("includes/header.php");

?>


<div class="page-wrapper">
	<div class="content container-fluid">
	   
	   <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Roles</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Roles</li>
					</ol>
					<button class="btn btn-danger float-right veiwbutton ml-3" onclick="getForm('addRole')">
					   <i class="fa fa-plus-circle"></i> Add Role
					</button>
				</div>
			</div>
		</div>
	
		<div class="page-header">
			<div class="row">
			  <div class="col-12">
				<?php echo $alert; ?>
			  </div>
			</div>
			
			<div class="row">
			   <div class="col-sm-12">
				  <div class="card card-table">
					<div class="card-body booking_card">
						<div class="table-responsive">
							<table class="datatable table table-stripped table table-hover table-center mb-0">
								<thead>
									<tr>
										<th>#</th>
										<th>Role</th>
										<th>Market</th>
										<th>Server</th>
										<th>Status</th>
										<th>Created_At</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tbody>
								 <?php
								   foreach( $result as $key=>$row ){ ?>
									<tr>
									    <td><?=++$key?></td>
										<td><?=$row["role"]?></td>
										<td><?=$row["market"]?></td>
										<td>
											<button class="btn btn-status p-0" onclick="getConnection('<?=$row["id"]?>', '<?=$row["role"]?>')">
											  <i class="fa fa-eye text-info"></i> View
											</button>
										</td>
										<td>
										  <button type="submit" class="btn btn-status <?php echo $row["status"] == 1 ? 'btn-success' : 'btn-secondary' ?>" onclick="updateStatusOnDB('<?=$row["id"]?>','dR','<?=$row["status"]?>')">
											   <?php echo $row["status"] == 1 ? 'Active' : 'Inactive' ?>
										  </button>
										</td>
										<td><?=date('d-M-Y', strtotime($row["created_at"]))?></td>
										<td class="text-right">
											<div class="dropdown dropdown-action d-inline">
											  <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											   <i class="fa fa-ellipsis-v ellipse_color"></i>
											  </a>
											  
											  <div class="dropdown-menu dropdown-menu-right">
												  <button class="dropdown-item" onclick="editForm('<?=$row["id"]?>','dR')">
													<i class="fa fa-pencil-square-o m-r-5 text-primary"></i> Edit Role
												  </button>
												  
												  <button class="dropdown-item" onclick="deleteOnDB('<?=$row["id"]?>','<?=$row["role"]?>','dR')">
												   <i class="fa fa-trash-o m-r-5 text-danger"></i> Delete Role
												  </button>
												  
												  <button class="dropdown-item" onclick="AssigneOrDeleteForm('<?=$row["id"]?>','Connect')">
												   <i class="fa fa-plug m-r-5 text-warning"></i>Add / Delete Server</i>
												  </button>
												</div>
											  </div>
										  </td>
									   </tr>
								   <?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			 </div>
		 </div>
	  </div>
   </div>
</div>


	
<!-- Modal's -->
 <div id="getConnectionModal"></div>
 <div id="getFormModal"></div>
 <div id="getStatusModal"></div>
<!-- Model's -->



<!-- jQuery -->
<script>
	var element = document.getElementById("Roles");
	   element.classList.add("active");
</script>
<?php include("includes/footer.php"); ?>
