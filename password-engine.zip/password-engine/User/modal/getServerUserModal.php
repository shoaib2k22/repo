<?php
include('../../dbConnection.php');

$server_id = trim($_POST['server']);

$sSql = "SELECT id, user FROM server_users WHERE server_id = '$server_id'";   
	$sResult = $conn->query($sSql);	
?>

 <label for="server">Select user</label>
 <select class="item inn form-control" name="s_user" id="s_user" onchange="getReqButton(this.value)"> 
	  <option value="" disabled selected>Select user</option> 
		<?php 
		  while($sRow = mysqli_fetch_array($sResult)) { ?> 
			  <option value="<?php echo $sRow['id']; ?>"><?php echo $sRow['user']; ?></option>
	   <?php } ?>				 
 </select>
 