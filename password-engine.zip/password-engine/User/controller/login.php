<?php

include('../dbConnection.php');

   if(!isset($_SESSION['is_user_login'])){
	  if(isset($_REQUEST['uEmail'])){
		$uEmail = mysqli_real_escape_string($conn,trim($_REQUEST['uEmail']));
		$uPassword = mysqli_real_escape_string($conn,trim($_REQUEST['uPassword']));
		$sql = "SELECT email, password, f_name, l_name, role FROM users WHERE email='".$uEmail."' AND password='".$uPassword."' limit 1";
		$result = $conn->query($sql);
		if($result->num_rows == 1){
		  $_SESSION['is_user_login'] = true;
		  $_SESSION['uEmail'] = $uEmail;
		  error_log("Successfully logged in by user ".$uEmail." at ".date('d-m-Y H:i:s')."\n", 3, "../audit_logs/userLogin.log");
		  // Redirecting to RequesterProfile page on Correct Email and Pass
		  echo "<script> location.href='dashboard.php'; </script>";
		  exit;
		} else {
		  error_log("Unsuccessful login attempt by user ".$uEmail." at ".date('d-m-Y H:i:s')."\n", 3, "../audit_logs/userLogin.log");
		  $msg = '<div class="alert alert-warning mt-2" role="alert"> Enter Valid Email and Password </div>';
		}
	  }
	}
	elseif($_SESSION['is_user_login']==1){
		 
		 // Redirecting to RequesterProfile page on Correct Email and Pass
		 echo "<script> location.href='dashboard.php'; </script>";
		 exit;
	}
	else {
	  echo "oooo";
	  exit;
	  echo "<script> location.href='index.php'; </script>";
    }

?>