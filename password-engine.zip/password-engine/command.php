<?php
header('Access-Control-Allow-Origin: *');
//echo get_current_user();
echo "command";
?>