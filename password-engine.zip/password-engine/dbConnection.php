<?php
date_default_timezone_set('Asia/Calcutta');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);
error_reporting(0);

session_start();

$hostName = "localhost";
$userName = "root";
$password = "";
$dbName = "accusr";
//$conn = oci_connect($username, $password, $dbname);

$conn = mysqli_connect($hostName, $userName, $password, $dbName);

if(!$conn){
	error_log("Unable to connect to Application Database because ".mysqli_connect_error($conn)." on ".date('d-m-Y H:i:s')."\n", 3, "../audit_logs/error.log");
	echo "<script> location.href='../index.php'; </script>";
}
 

?>