<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$connection = ssh2_connect('vgg218yr', 22);
ssh2_auth_password($connection, 'alive007', 'Acc@0323');

//$tunnel = ssh2_tunnel($connection, 'vgssh3hr:22', 22);

//$tunnel = ssh2_shell($connection, 'vgssh3hr', null, 22, 24, SSH2_TERM_UNIT_CHARS);

//usr/bin/curl -k -u  "VF-ROOT\LIVE008IA":"Bot08@0323" -X POST -H "Content-Type:application/json" -d @input.txt "https://oo.vodafone.com/oo/rest/v2/executions";

//{"flowUuid":"e1a53093-7da0-4f04-8819-92abb065f18a","runName":"Test"}

//echo shell_exec('curl -k -u "VF-ROOT\LIVE008IA":"Bot08@0323" -X POST -H "Content-Type:application/json" -d "{\"flowUuid\":\"e1a53093-7da0-4f04-8819-92abb065f18a\",\"runName\":\"Test\"}" "https://oo.vodafone.com/oo/rest/v2/executions"');


if(!$connection){
	echo "Not connected";
}

//$stream = ssh2_exec($connection, 'curl -k -u "VF-ROOT\LIVE008IA":"Bot08@0323" -X POST -H "Content-Type:application/json" -d "{\"flowUuid\":\"e1a53093-7da0-4f04-8819-92abb065f18a\",\"runName\":\"Test\"}" "https://oo.vodafone.com/oo/rest/v2/executions"');

$stream = ssh2_exec($connection, 'ksh /tmp/scripts/icms1.ksh vg6672yw 2>&1');


//$stream = ssh2_exec($stream1, "pwd");

//$stream = ssh2_tunnel($connection, 'vgssh3hr', 22);



 stream_set_blocking($stream, true);
   $output = ssh2_fetch_stream($stream, SSH2_STREAM_STDIO);
   echo stream_get_contents($output);
  




/* include('MTS/MTS/EnableMTS.php');

//first you get a shell on the first server:
 $shellObj = \MTS\Factories::getDevices()->getRemoteHost('vgg218yr')->setConnectionDetail('alive007', 'Acc@0323')->getShell();

print_r($shellObj); exit();
//then build on that first shell, the following way.
\MTS\Factories::getDevices()->getRemoteHost('vgssh3hr')->setConnectionDetail('alive007', 'Acc@0323')->getShell($shellObj);


//any command executed on the shell will run only on the second host you connected to.
$return1  = $shellObj->exeCmd("whoami");
echo $return1;//hostname of the second host you connected to */


?>