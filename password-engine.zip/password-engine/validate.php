<?php

$serverName = $_REQUEST['serverName'];
$userName = $_REQUEST['userName'];
$userPassword = $_REQUEST['userValue'];

/* copy('input.json', 'input_temp.json');
chmod('input_temp.json', 0777);

$str = file_get_contents('input_temp.json');
$str = str_replace('serverName', $serverName, $str);
$str = str_replace('userName', $userName, $str);
$str = str_replace('userValue', $userValue, $str);
file_put_contents('input_temp.json', $str);

$connection = ssh2_connect('vgg218yr', 22);
ssh2_auth_password($connection, 'alive007', 'Acc@0323');

$stream = ssh2_exec($connection, 'curl -u "VF-ROOT\LIVE008IA":"Bot08@0323" -X POST -H "Content-Type:application/json" -d @newinput.json "https://oo.vodafone.com/oo/rest/v2/executions"');

unlink('input_temp.json'); */

$stream = 'xyz';

if($stream){
	$myObj = new stdClass();
	$myObj->code = 200;
	$myObj->msg = "Validation Successful";
	$myJSON = json_encode($myObj);
	echo $myJSON;
	die();
}
else{
	$myObj = new stdClass();
	$myObj->code = 400;
	$myObj->msg = "Validation False: Please check your Service/Funnctional User Name & User Password";
	$myJSON = json_encode($myObj);
	echo $myJSON;
	die();
}

    
  

?>